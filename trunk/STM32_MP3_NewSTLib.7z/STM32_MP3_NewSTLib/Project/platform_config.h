/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PLATFORM_CONFIG_H
#define __PLATFORM_CONFIG_H
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Uncomment the line corresponding to the STMicroelectronics evaluation board
   used to run the example */
#if !defined (USE_STM3210B_EVAL)
 #define USE_STM3210B_EVAL
#endif

#define CHAR		char
#define BYTE		unsigned char
#define WORD		unsigned short
#define DWORD		unsigned int
#define uint8		unsigned char
#define int8		signed char
#define uint16		unsigned short
#define int16		signed short
#define uint32		unsigned int
#define int32		signed int

#endif /* __PLATFORM_CONFIG_H */
