#ifndef __CC_ARCH_H__
#define __CC_ARCH_H__

#define PACK_STRUCT_FIELD(x) x __attribute__((packed))
#define PACK_STRUCT_STRUCT __attribute__((packed))
#define PACK_STRUCT_BEGIN
#define PACK_STRUCT_END

#endif /* __CC_ARCH_H__ */
