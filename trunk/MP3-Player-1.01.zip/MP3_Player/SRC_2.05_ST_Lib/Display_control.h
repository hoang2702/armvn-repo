/********************* Kasper Jepsen *******************/
/**
*
* @file     Display_Control.h
* @brief    Updates the display with buttons and flying text
* @author   Kasper
* @date     06/2009
*
* @version  1.0
* @date     
*
**/
/******************************************************************************/



// Definition for the positions of the push buttons
#define pic_width_size 32
#define pic_height_size 32
#define pic_row_1 90
#define pic_row_2 48
#define pic_row_3 6
// 3 columns
#define pic_col_1 90
#define pic_col_2 48
#define pic_col_3 6
// 2 columns
#define pic_col_4 16
#define pic_col_5 64

// Time for Scroll of text
#define scroll_time 100
#define scroll_wait 400

// Type to hold the different icons and their positions
typedef struct
   {
   u16 *bmp;
   u8 xpos;
   u8 ypos;
   } tButInfo;

// Enumurator to give the array index names
typedef enum 
   {
   No_Button = -1,
   Eject,
   //FFwd,
   //FRev,
   //Next,
   Off,
   Play,
   //Prev,
   Stop   
   } etouch_pressed;

// Enumurator to the button state
typedef enum 
   {
   Not_Pressed = 0,
   Pressed = 1
   } etouch_bt_state;

// Type to hold data for the Flying text
typedef struct
    {
    char text[64]; // Maximum 64 chars
    u8 text_length; // Length of the text
    u8 curr_pos; // Current pointer for first char to write
    u8 x; // Position to write first char
    u8 y; // Position to write first char
    u8 disp_length; // How many chars to show on screen
    u16 time; // How fast to roll the text
    } tflying_text;


// Type used to read out ID3 Tag, this type fits to the ID3V1 Format
typedef struct
    {
    char tag[3];
    char title[30];
    char artist[30];
    char album[30];
    char year[4];
    char comment[30];
    u8 genre;
    } tID3V3;

// The variable for the flying text can be filled in external
extern tflying_text flying_text[1];

// Prototypes
void Draw_Display();
void flying_text_write(tflying_text data_struct[],u32 array_count);
void flying_text_clear(tflying_text data_struct[],u32 array_count);
void scroll_text();