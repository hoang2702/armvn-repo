/********************* Kasper Jepsen *******************/
/**
*
* @file     Display_Control.h
* @brief    Updates the display with buttons and flying text
* @author   Kasper
* @date     06/2009
*
* @version  1.0
* @date     
*
**/
/******************************************************************************/


/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_lib.h"
#include "circle_api.h"
#include "Display_control.h"


/* Public variables ---------------------------------------------------------*/
tflying_text flying_text[1];


/* Private variables ---------------------------------------------------------*/
etouch_bt_state Last_button_state = Not_Pressed;

/* Reserved for future use
static const u16 ButtonFFwdBmp [] = {
#include "bmp\Player FastFwd.h"
    };

static const u16 ButtonFRevBmp [] = {
#include "bmp\Player FastRev.h"
    };

static const u16 ButtonNextBmp [] = {
#include "bmp\Player Next.h"
    };

static const u16 ButtonPauseBmp [] = {
#include "bmp\Player Pause.h"
    };

static const u16 ButtonPrevBmp [] = {
#include "bmp\Player Previous.h"
    };
*/

static const u16 ButtonPlayBmp [] = {
#include "bmp\Player Play.h"
    };

static const u16 ButtonEject [] = {
#include "bmp\Player Eject.h"
    };

static const u16 ButtonStopBmp [] = {
#include "bmp\Player Stop.h"
    };

static const u16 ButtonOffBmp [] = {
#include "bmp\Player Off.h"
    };


const tButInfo ButInfo[] = {
{(u16 *)&ButtonEject,pic_col_1 , pic_row_1},
/*{(u16 *)&ButtonFFwdBmp,pic_col_2, pic_row_1},
{(u16 *)&ButtonFRevBmp,pic_col_1, pic_row_1},
{(u16 *)&ButtonNextBmp,pic_col_3, pic_row_2},*/
{(u16 *)&ButtonOffBmp,pic_col_2, pic_row_2},
{(u16 *)&ButtonPlayBmp,pic_col_3, pic_row_1},
/*{(u16 *)&ButtonPrevBmp,pic_col_4, pic_row_3},*/
{(u16 *)&ButtonStopBmp,pic_col_2, pic_row_1},
};






/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
*
*                            Draw_Display
*
*******************************************************************************/
/**
*
*   Draw the icons on the screen at the specified position
*
*   @param[in] mode      : Pointer to the audio file there is selected
*
*  
**/
/******************************************************************************/
void Draw_Display(PFILEINFO local_file_info)
    {
    u32 i;
    DRAW_Clear();
    for (i=0;i<(sizeof(ButInfo)/sizeof(tButInfo));i++)
    DRAW_SetImage(ButInfo[i].bmp, ButInfo[i].xpos , ButInfo[i].ypos, pic_width_size, pic_height_size) ;  
    }


/*******************************************************************************
*
*                            Get_Touch
*
*******************************************************************************/
/**
*
*   Scans through the touch buttons on screen and return the input
*
*   @return   : The value for the key there has been pressed else No_Button is returned
*
*   
**/
/******************************************************************************/
etouch_pressed Get_Touch()
{
u16 pos;
u8 xpos;
u8 ypos;
if (TOUCHSCR_IsPressed())   // Check if touch is pressed
    {
    if  (Last_button_state == Not_Pressed)
        {
        pos = TOUCHSCR_GetPos (); // Get Cordinated for pressed point
        xpos = pos & 0x00FF;
        ypos = pos >>8;
        /* Pos now used as loop */
        for (pos=0;pos<(sizeof(ButInfo)/sizeof(tButInfo));pos++) // Loop through buttons until key is found
            {
            if((xpos > ButInfo[pos].xpos) & (xpos<ButInfo[pos].xpos+ pic_width_size))
                {
                if((ypos > ButInfo[pos].ypos) & (ypos<ButInfo[pos].ypos+ pic_height_size))
                     {
                     Last_button_state = Pressed;  
                     return (etouch_pressed)pos;
                     } 
                 }
            }
        }
    Last_button_state = Pressed;    
    }
    else
        Last_button_state = Not_Pressed;
 return No_Button;
}




/*******************************************************************************
*
*                            Read_ID3V1
*
*******************************************************************************/
/**
*
*   Read the ID3 Tag from the MP3, and add it to the flying text array
*
*   @param[in] mode      : Pointer to the audio file there is selected
*
*   
**/
/******************************************************************************/
void Read_ID3V1(PFILEINFO local_file_info)
    {
    tID3V3 tst_buff;
    char temp_buffer[31];
    u32 i,i_temp;
    FS_Seek  ( local_file_info,local_file_info->filelen-sizeof(tst_buff));   
    FS_ReadFile(local_file_info, &tst_buff, &i, sizeof(tst_buff)); 
    FS_Seek  ( local_file_info,0);       
    
    if ( strstr(tst_buff.tag, "TAG") )
        {
        flying_text[0].text_length = 0;
        // Below codes copy the title and leave empty spaces after title out.
        for(i=29;i>0;i--)
            {
            if((tst_buff.artist[i] != 0x20)&&(tst_buff.artist[i] != 0x00))
                {
                for(i=i;i>0;i--)
                    {
                    flying_text[0].text[i]=tst_buff.artist[i] ;
                    flying_text[0].text_length++;
                    }       
                flying_text[0].text[i]=tst_buff.artist[i] ; // Copy the last char..
                flying_text[0].text_length++;
                break;
                }
            }
    
        flying_text[0].text[flying_text[0].text_length]= ' ';
        flying_text[0].text[flying_text[0].text_length+1]= '-';
        flying_text[0].text[flying_text[0].text_length+2]= ' ';
        flying_text[0].text_length=flying_text[0].text_length+3;
        i_temp=flying_text[0].text_length;
        
        // Below codes copy the title and leave empty spaces after title out.
        for(i=29;i>0;i--)
            {
            if((tst_buff.title[i] != 0x20)&&(tst_buff.title[i] != 0x00))
                {
                flying_text[0].text[i+1+i_temp] = '0'; // Terminate string
                for(i=i;i>0;i--)
                    {
            
                    flying_text[0].text[i+i_temp]=tst_buff.title[i] ;
                    flying_text[0].text_length++;

                    }
               
                flying_text[0].text[i+i_temp]=tst_buff.title[i] ; // Copy the last char..
                flying_text[0].text_length++;

                break;
                }
            }
        }
    }



/*******************************************************************************
*
*                            flying_text_write
*
*******************************************************************************/
/**
*
*   Handles the update of the flying text, so it can roll the text
*
*   @param[in] mode      : Array of tflying_text structs with data to be written on screen
*   @param[in] mode      : How many items in the array
*
*   
**/
/******************************************************************************/
void flying_text_write(tflying_text data_struct[],u32 array_count)
    {
    u32 i; 
    for(i=0;i<array_count;i++)
        {
        if ((data_struct[i].time>scroll_time) && (data_struct[i].time<scroll_time+10) && data_struct[i].disp_length > 0)
            {
            DRAW_DisplayString (data_struct[i].x, data_struct[i].y, data_struct[i].text+data_struct[i].curr_pos, data_struct[i].disp_length);
            data_struct[i].curr_pos++;

            if (data_struct[i].curr_pos+data_struct[i].disp_length > data_struct[i].text_length)
                {    
                data_struct[i].curr_pos=0;
                data_struct[i].time=scroll_time+10;
                }
            else if (data_struct[i].curr_pos ==1)
                data_struct[i].time=scroll_time+10;
            else
                data_struct[i].time=0;
            }
        if (data_struct[i].time>scroll_time+10+scroll_wait) 
            data_struct[i].time=0;
        data_struct[i].time++;
        }    

    }


/*******************************************************************************
*
*                            flying_text_clear
*
*******************************************************************************/
/**
*
*   Deletes the text written by flying text
*
*   @param[in] mode      : Array of tflying_text structs with data to be written on screen
*   @param[in] mode      : How many items in the array
*
*   Note: This function also deletes the information about bitrate / audio channels
*   
**/
/******************************************************************************/
void flying_text_clear(tflying_text data_struct[],u32 array_count)
    {
    u32 i; 
    for(i=0;i<array_count;i++)
    DRAW_DisplayString (data_struct[i].x, data_struct[i].y, "                  " , data_struct[i].disp_length);   
    DRAW_DisplayString (0, 5, "                  " , 18);   
    }

