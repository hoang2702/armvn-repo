#include 	"stm32f10x_lib.h"
#include 	"platform_config.h"

#ifndef 	__FAT_H
#define 	__FAT_H
#include 	<stdio.h>
#include 	<string.h>

#include 	"fat.h"
//--------------------------------------------------------------------------//
DWORD 	FirstDirClust;    	//first directory cluster
DWORD 	FirstDataSector;	// The first sector number of data
WORD 	BytesPerSector;		// Bytes per sector
DWORD 	FATsectors;			// The amount sector a FAT occupied
WORD 	SectorsPerClust;	// Sector per cluster
DWORD 	FirstFATSector;		// The first FAT sector
DWORD 	FirstDirSector;		// The first Dir sector
DWORD 	RootDirSectors;		// The sector number a Root dir occupied 
DWORD 	RootDirCount;		// The count of directory in root dir
BYTE 	FAT32_Enable;

extern uint8 dis;

#if FAT_BUFFERED

	BYTE TABLE_READ = 0;
	DWORD START_CLUSTER = 0x0ffffff8;	//when the mcu has large ram
	BYTE FAT_TABLE[512];				//when the mcu has large ram
#endif

BYTE LongNameBuffer[MAX_LONG_NAME_SIZE];
//
BYTE LongName_in[80];
//
BYTE LongNameFlag = 0;

BYTE (* FAT_ReadSector)(DWORD,BYTE *);
BYTE (* FAT_WriteSector)(DWORD,BYTE *);
DWORD (* FAT_ReadCapacity)(void);

struct FileInfoStruct FileInfo;//temporarily buffer for file information
//-------------------------------------------------------------------------//
BYTE FAT_Init()//Initialize of FAT  need initialize SD first
{
	struct bootsector710 *bs  = 0;
	struct bpb710Bytes *bpb = 0;
	struct partrecordBytes *pr  = 0;

	BYTE buffer[512];
	DWORD hidsec=0;
	DWORD Capacity;

	Capacity = FAT_ReadCapacity();
	

	if(Capacity<0xff)
		return 1;


	if(FAT_ReadSector(0,buffer))//ho tro the SD 1G tro len
		return 1;
	bs = (struct bootsector710 *)buffer;

	pr = (struct partrecordBytes*)((struct partsector*)buffer)->psPart;//first partition
	hidsec = get32_little(pr->prStartLBA);//the hidden sectors
	if(hidsec >= Capacity/512)
	{
		hidsec = 0;
	}
	else 
	{
		if(FAT_ReadSector(get32_little(pr->prStartLBA),buffer))return 1;//read the bpb sector
		bs = (struct bootsector710 *)buffer;
		if(bs->bsJump[0]!=0xE9 && bs->bsJump[0]!=0xEB)
		{
			hidsec = 0;
			if(FAT_ReadSector(0,buffer))return 1;//read the bpb sector
			bs = (struct bootsector710 *)buffer;	
		}
	}

	if(bs->bsJump[0]!=0xE9 && bs->bsJump[0]!=0xEB)//�Ը�û��bootsect��sd��	//dead with the card which has no bootsect
	{
		return 1;
	}
	

	bpb = (struct bpb710Bytes*)bs->bsBPB;

	
	if(get16_little(bpb->bpbFATsecs))//detemine thd FAT type  //do not support FAT12
	{
		FAT32_Enable=0;	//FAT16
		FATsectors		= get16_little(bpb->bpbFATsecs);//the sectors number occupied by one fat talbe
		FirstDirClust = 2;
	}
	else
	{
		FAT32_Enable=1;	//FAT32
		FATsectors		= get32_little(bpb->bpbBigFATsecs);//the sectors number occupied by one fat talbe
		FirstDirClust = get32_little(bpb->bpbRootClust);
	}

	BytesPerSector	= get16_little(bpb->bpbBytesPerSec);
	SectorsPerClust	= bpb->bpbSecPerClust;
	FirstFATSector	= get16_little(bpb->bpbResSectors)+hidsec;
	RootDirCount	= get16_little(bpb->bpbRootDirEnts);
	RootDirSectors	= (RootDirCount*32)>>9;
	FirstDirSector	= FirstFATSector+bpb->bpbFATs*FATsectors;
	FirstDataSector	= FirstDirSector+RootDirSectors;

	printf ("\r\nBytesPerSector %d",BytesPerSector);
	return 0;
}
//-------------------------------------------------------------------------//
BYTE FAT_LoadPartCluster(DWORD cluster,BYTE part,BYTE * buffer)
{
	DWORD sector;
	sector=(DWORD)FirstDataSector+(DWORD)(cluster-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
	if(FAT_ReadSector(sector+part,buffer))return 1;
	else return 0;
}
//-------------------------------------------------------------------------//
#if FAT_BUFFERED
/* have 512 byte to buffer the fat table, for large ram device */
DWORD FAT_NextCluster(DWORD cluster)
{
	BYTE temp;
	DWORD sector;
	DWORD offset;

	if(cluster<2)return 0x0ffffff8;

	if(FAT32_Enable)temp = 127;
	else temp = 255;
	
	offset = cluster/(temp+1);		
	sector=FirstFATSector+offset;//calculate the actual sector where the FAT placed

	offset=cluster%(temp+1);//find the position
	cluster -= offset;

	if(TABLE_READ == 0 || cluster != START_CLUSTER)
	{
		if(FAT_ReadSector(sector,FAT_TABLE)) 
			return 0x0ffffff8;//read fat table / return 0xfff8 when error occured
		START_CLUSTER = cluster;
		TABLE_READ = 1;
	}

	if(FAT32_Enable)
	{
	//	offset=cluster%128;//find the position
		sector=((DWORD *)FAT_TABLE)[offset];	
	}
	else
	{
	//	offset=cluster%256;//find the position
		sector=((WORD *)FAT_TABLE)[offset];
	}
	return (DWORD)sector;//return the cluste number
}

#else
//Return the cluster number of next cluster of file
//Suitable for system which has limited RAM
DWORD FAT_NextCluster(DWORD cluster)
{
	BYTE buffer[512];
	DWORD sector;
	DWORD offset;
	
	if(FAT32_Enable)offset = cluster/128;
	else offset = cluster/256;
	if(cluster<2)return 0x0ffffff8;
	sector=FirstFATSector+offset;//calculate the actual sector
	if(FAT_ReadSector(sector,buffer))return 0x0ffffff8;//read fat table / return 0xfff8 when error occured

	if(FAT32_Enable)
	{
		offset=cluster%128;//find the position
		sector=((DWORD *)buffer)[offset];	
	}
	else
	{
		offset=cluster%256;//find the position
		sector=((WORD *)buffer)[offset];
	}
	return (DWORD)sector;//return the cluste number
}

#endif

#if 0
//-------------------------------------------------------------------------//
//Find a free cluster return the cluster number
DWORD FAT_FindFreeCluster()
{
	BYTE buffer[512];
	//DWORD sector;
	unsigned int i;
	DWORD cnt;
//	sector=FirstFATSector+offset;//calculate the actual sector
	//sector=FirstFATSector;
	if(FAT32_Enable)
	{
		for(cnt=0;cnt<FATsectors;cnt++)//find in the FAT table
		{
			if(FAT_ReadSector(FirstFATSector+cnt,buffer))return 1;//error
			for(i=0;i<128;i++)
			{
				if(((DWORD *)buffer)[i]==0x00000000)break;//an unused cluster
			}
			if(i!=128)
			{
				cnt=cnt*128+i;
				return cnt;//return the free cluster number
			}
		}
	}
	else
	{
		for(cnt=0;cnt<FATsectors;cnt++)//find in the FAT table
		{
			if(FAT_ReadSector(FirstFATSector+cnt,buffer))return 1;//error
			for(i=0;i<256;i++)
			{
				if(((unsigned int *)buffer)[i]==0x0000)break;//an unused cluster
			}
			if(i!=256)
			{
				cnt=cnt*256+i;
				return cnt;//return the free cluster number
			}
		}
	}
	return 1;//error
}

//-------------------------------------------------------------------------//
//find a position to place a item withe the given directory, the parameter is FileInfo who brought the message
unsigned int FAT_FindFreeItem(DWORD cluster, struct FileInfoStruct *FileInfo)
{
	BYTE *buffer;
	DWORD tempclust;
	DWORD sector;
	unsigned int cnt;
	unsigned int offset;
//	unsigned char i;
	struct direntry *item = 0;
	if(cluster==0 && FAT32_Enable==0)// root directory//
	{
		buffer=malloc(512);//apply memory
		if(buffer==0)return 1;//if failed
		for(cnt=0;cnt<RootDirSectors;cnt++)
		{
			if(FAT_ReadSector(FirstDirSector+cnt,buffer)){free(buffer);return 1;}//read sector
			for(offset=0;offset<512;offset+=32)
			{
				item=(struct direntry *)(&buffer[offset]);
				//used item
				if(item->deName[0] == 0x00 || item->deName[0] == 0xe5)
				//unused item
				{

					FileInfo->StartCluster = item->deStartCluster + (((DWORD)item->deHighClust)<<16);//don't care
					FileInfo->Size         = item->deFileSize;//don't care
					FileInfo->Attr         = item->deAttributes;//don't care
					FileInfo->Sector       = FirstDirSector+cnt;//The key parameter record the secoter nuber which the item stored
					FileInfo->Offset       = offset;			//The key parameter record the offset in the sector
					free(buffer);//realease
					return 0;//done
				}
			}
		}
		free(buffer);//release
	}
	else//other folders
	{
		tempclust=cluster;
		while(1)
		{
			sector=(DWORD)FirstDataSector+(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
			buffer=malloc(512);//apply memory
			if(buffer==0)return 1;//if failed
			for(cnt=0;cnt<SectorsPerClust;cnt++)
			{
				if(FAT_ReadSector(sector+cnt,buffer)){free(buffer);return 1;}
				for(offset=0;offset<512;offset+=32)
				{
					item=(struct direntry *)(&buffer[offset]);
					if(item->deName[0] == 0x00 || item->deName[0] == 0xe5)
					{
						FileInfo->StartCluster = item->deStartCluster + (((DWORD)item->deHighClust)<<16);						
						FileInfo->Size         = item->deFileSize;
						FileInfo->Attr         = item->deAttributes;
						FileInfo->Sector       = sector+cnt;
						FileInfo->Offset       = offset;
						free(buffer);
						return 0;
					}
				}
			}
			free(buffer);//release
			tempclust=FAT_NextCluster(tempclust);//next cluster
			if( (FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0ffffff8 || tempclust == 0x0fffffff)return 1;
		}
	}
	return 1;
}
//--------------------------------------------------------------------------------//
//display the content of a foler , 0 as root directory
unsigned char FAT_DisDir(BYTE *dir)
{
	BYTE *buffer;
	DWORD sector;
	DWORD cluster;
	DWORD tempclust;
	unsigned int cnt;
	unsigned int offset;
	unsigned char i;
	struct direntry *item = 0;
	cluster = FAT_OpenDir(dir);
	if(cluster == 1)return 1;
	if(cluster==0 && FAT32_Enable==0)// root directory
	{
		buffer=malloc(512);//apply memory
		if(buffer==0)return 1;//if failed
		for(cnt=0;cnt<RootDirSectors;cnt++)
		{
			if(FAT_ReadSector(FirstDirSector+cnt,buffer)){free(buffer);return 1;}
			for(offset=0;offset<512;offset+=32)
			{
				item=(struct direntry *)(&buffer[offset]);//pointer convert
				//find a valid item and display it
				if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
				{
					printf ("%c",0x0d);
					printf ("%c",0x0a);
					for(i=0;i<8;i++)//name
					{
						printf ("%c",item->deName[i]);	
					}
					if((item->deAttributes & 0x10)==0)printf ("%c",'.');
					for(i=0;i<3;i++)//extention
					{
						printf ("%c",item->deExtension[i]);
					}
				}
			}
		}
		free(buffer);//release
	}
	else//other folders
	{
		tempclust=cluster;
		while(1)
		{
			sector=(DWORD)FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
			buffer=malloc(512);//apply memory
			if(buffer==0)return 1;//if failed
			for(cnt=0;cnt<SectorsPerClust;cnt++)
			{
				if(FAT_ReadSector(sector+cnt,buffer)){free(buffer);return 1;}
				for(offset=0;offset<512;offset+=32)
				{
					item=(struct direntry *)(&buffer[offset]);
					if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
					{
						printf ("%c",0x0d);
						printf ("%c",0x0a);
						for(i=0;i<8;i++)
						{
							printf ("%c",item->deName[i]);	
						}
						if((item->deAttributes & 0x10)==0)printf ("%c",'.');
						for(i=0;i<3;i++)
						{
							printf ("%c",item->deExtension[i]);
						}
					}
				}
			}
			free(buffer);//release
			tempclust=FAT_NextCluster(tempclust);//next cluster
			if( tempclust == 0x0ffffff8 )return 1;
			if((FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0fffffff)break;
		}
	}
	return 0;
}
//--------------------------------------------------------------------------------//
//select the first unsed item in the given cluster
//for delete a foler or a file
unsigned char FAT_SelectOneItem(DWORD cluster,struct FileInfoStruct *FileInfo)
{
	BYTE *buffer;
	DWORD tempclust;
	DWORD sector;
	unsigned int cnt;
	unsigned int offset;
//	unsigned char i;
	struct direntry *item = 0;
	if(cluster==0 && FAT32_Enable==0)// root directory
	{
		buffer=malloc(512);//apply memory
		if(buffer==0)return 1;//if failed
		for(cnt=0;cnt<RootDirSectors;cnt++)
		{
			if(FAT_ReadSector(FirstDirSector+cnt,buffer)){free(buffer);return 1;}
			for(offset=0;offset<512;offset+=32)
			{
				item=(struct direntry *)(&buffer[offset]);
				if((item->deName[0] != 0x00) && (item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
				{
					//return the parameter of the item
					FileInfo->StartCluster = item->deStartCluster + (((DWORD)item->deHighClust)<<16);//don't care
					FileInfo->Size         = item->deFileSize;
					FileInfo->Attr         = item->deAttributes;
					FileInfo->Sector       = FirstDirSector+cnt;
					FileInfo->Offset       = offset;
					free(buffer);
					return 0;
				}
			}
		}
		free(buffer);//release
	}
	else//other folders
	{
		tempclust=cluster;
		while(1)
		{
			sector=(DWORD)FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
			buffer=malloc(512);//apply memory
			if(buffer==0)return 1;//if failed
			for(cnt=0;cnt<SectorsPerClust;cnt++)
			{
				if(FAT_ReadSector(sector+cnt,buffer)){free(buffer);return 1;}
				for(offset=0;offset<512;offset+=32)
				{
					item=(struct direntry *)(&buffer[offset]);
					if((item->deName[0] != 0x2e) && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5) & (item->deAttributes != 0x0f))
					{
						FileInfo->StartCluster = item->deStartCluster + (((DWORD)item->deHighClust)<<16);//don't care
						FileInfo->Size         = item->deFileSize;
						FileInfo->Attr         = item->deAttributes;
						FileInfo->Sector       = sector+cnt;
						FileInfo->Offset       = offset;
						free(buffer);
						return 0;
					}
				}
			}
			free(buffer);//release
			tempclust=FAT_NextCluster(tempclust);//next cluster
			if((FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0ffffff8 || tempclust == 0x0fffffff)break;
		}
	}
	return 1;
}

//--------------------------------------------------------------------------------//
//modify the fat table item with "val","cluster" specify the location
unsigned char FAT_ModifyFAT(DWORD cluster,DWORD val)
{
	BYTE buffer[512];
	DWORD sector;
	DWORD offset;
	if(FAT32_Enable)offset = cluster/128;
	else            offset = cluster/256;

	sector=FirstFATSector+offset;//calculate the actual sector
	if(FAT_ReadSector(sector,buffer))return 1;//read fat table

	if(FAT32_Enable)
	{
		offset=cluster%128;
		offset<<=2;
		buffer[offset+3]=val>>24;
		buffer[offset+2]=val>>16;
		buffer[offset+1]=val>>8;
		buffer[offset]=val;
	}
	else
	{
		offset=cluster%256;//find the position
		offset<<=1;
		buffer[offset+1] = val>>8;
		buffer[offset]   = val;
	}
	//sector=buffer[offset+1];
//	sector<<=8;
	//sector+=buffer[offset];
	if(FAT_WriteSector(sector,buffer))return 1;//write the first fat table
	if(FAT_WriteSector(sector+FATsectors,buffer))return 1;//write the second fat table
	return 0;//return the value
}
//--------------------------------------------------------------------------------//
// make a dir
unsigned char FAT_MkDir(BYTE * dir)
{
	BYTE name[11];
	BYTE *p=dir;
	BYTE deep=0;
	WORD i,j;
	DWORD cluster=0;
	DWORD lastcluster;//cluster number of last directory
	BYTE *buffer;
	DWORD sector;
	struct direntry *item;
	if(FAT32_Enable)cluster=FirstDirClust;
	if(*p != '\\')return 1;//invalid path
	while(*p)
	{
		if(*p == '\\')
		{
			deep++;//the deepth of the path
		}
		p++;
	}
	p=dir;
	for(i=0;i<deep-1;i++)
	{
		p++;
		for(j=0;j<11;j++)name[j]=0x20;
		j=0;
		while(*p != '\\')
		{
			if((*p) >= 'a' && (*p) <= 'z')name[j] = (*p++)-0x20;
			else name[j] = *p++;
			j++;
		}
		if(FAT_FindItem(cluster,name, &FileInfo))return 1;//find the location of each directory
		cluster = FileInfo.StartCluster;//point to next directory
	}
	p++;
	for(j=0;j<11;j++)name[j]=0x20;
	j=0;
	while(*p)
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}
	lastcluster=cluster;//save as last directory
	cluster=FAT_FindFreeCluster();//find a unused cluster
	if(cluster==1)return 1;//error
	if(FAT_FindFreeItem(lastcluster,&FileInfo))return 1;//find a unused item
	buffer=malloc(512);
	if(buffer==0)return 1;
	if(FAT_ReadSector(FileInfo.Sector,buffer)){free(buffer);return 1;}//read the sector which the item is in
	item=(struct direntry *)(&buffer[FileInfo.Offset]);//pointer convert

	for(j=0;j<8;j++)item->deName[j] = name[j];
	for(j=0;j<3;j++)item->deExtension[j] = 0x20;
	item->deAttributes = ATTR_DIRECTORY;
	item->deLowerCase = LCASE_BASE | LCASE_EXT;
	item->deCHundredth = 0x00;
	item->deCTime[0] = 0x00;
	item->deCTime[1] = 0x60;
	item->deCDate[0] = 0x5c;
	item->deCDate[1] = 0x09;
	item->deADate[0] = 0x8e;
	item->deADate[1] = 0x35;
	item->deHighClust = cluster>>16;
	item->deMTime[0] = 0x00;
	item->deMTime[1] = 0x60;
	item->deMDate[0] = 0x50;
	item->deMDate[1] = 0x0a;
	item->deStartCluster = cluster;
	item->deFileSize = 0;
	if(FAT_WriteSector(FileInfo.Sector,buffer)){free(buffer);return 1;}//write the item

	for(j=0;j<512;j++)buffer[j]=0x00;
	sector=(DWORD)FirstDataSector+(DWORD)(cluster-2)*(DWORD)SectorsPerClust;
	for(i=0;i<SectorsPerClust;i++)
	{
		if(FAT_WriteSector(sector+i,buffer)){free(buffer);return 1;}//clear the data in the directory
	}

	//create "." directory
	item=(struct direntry *)(&buffer[0]);
	item->deName[0] = '.';
	for(j=1;j<8;j++)item->deName[j] = 0x20;
	for(j=0;j<3;j++)item->deExtension[j] = 0x20;
	item->deAttributes = ATTR_DIRECTORY;
	item->deLowerCase = LCASE_BASE | LCASE_EXT;
	item->deCHundredth = 0x00;
	item->deCTime[0] = 0x00;
	item->deCTime[1] = 0x60;
	item->deCDate[0] = 0x5c;
	item->deCDate[1] = 0x09;
	item->deADate[0] = 0x8e;
	item->deADate[1] = 0x35;
	item->deHighClust = cluster>>16;
	item->deMTime[0] = 0x00;
	item->deMTime[1] = 0x60;
	item->deMDate[0] = 0x50;
	item->deMDate[1] = 0x0a;
	item->deStartCluster = cluster;//the directory itself
	item->deFileSize = 0;

	//creat ".." directory
	item=(struct direntry *)(&buffer[32]);
	item->deName[0] = '.';
	item->deName[1] = '.';
	for(j=2;j<8;j++)item->deName[j] = 0x20;
	for(j=0;j<3;j++)item->deExtension[j] = 0x20;//no extention
	item->deAttributes = ATTR_DIRECTORY;//directory
	item->deLowerCase = LCASE_BASE | LCASE_EXT;
	item->deCHundredth = 0x00;
	item->deCTime[0] = 0x00;
	item->deCTime[1] = 0x60;
	item->deCDate[0] = 0x5c;
	item->deCDate[1] = 0x09;
	item->deADate[0] = 0x8e;
	item->deADate[1] = 0x35;
	item->deHighClust = lastcluster>>16;
	item->deMTime[0] = 0x00;
	item->deMTime[1] = 0x60;
	item->deMDate[0] = 0x50;
	item->deMDate[1] = 0x0a;
	item->deStartCluster = lastcluster;//last directory
	item->deFileSize = 0;

	if(FAT_WriteSector(sector,buffer)){free(buffer);return 1;}//write the data
	free(buffer);
	if(FAT32_Enable)
	{
		if(FAT_ModifyFAT(cluster,0x0fffffff))return 1;//modify the fat table to sign that the cluster was used 
	}
	else
	{
		if(FAT_ModifyFAT(cluster,0xffff))return 1;//modify the fat table to sign that the cluster was used 
	}
	return 0;//done
}
//--------------------------------------------------------------------------------//
// remove a directory
unsigned char FAT_RmDir(BYTE * dir)
{
	if(FAT_OpenDir(dir)==0)return 1;//find the directory
	if(FAT_DelItem(&FileInfo))return 1;//delete it
	return 0;
}
//--------------------------------------------------------------------------------//
// creat a file, for convenience we designate the size
// return the start sector of the new file
DWORD FAT_Create(BYTE * dir,DWORD size)
{
	BYTE name[11];
	BYTE *p=dir;
	BYTE deep=0;
	BYTE i,j;
	DWORD cluster=0;
	BYTE *buffer;
	//WORD sector;
	struct direntry *item;
	if(FAT32_Enable)cluster=FirstDirClust;
	if(*p != '\\')return 1;//invalid path
	while(*p)
	{
		if(*p == '\\')
		{
			deep++;
		}
		p++;
	}
	p=dir;
	for(i=0;i<deep-1;i++)
	{
		p++;
		for(j=0;j<11;j++)name[j]=0x20;
		j=0;
		while(*p != '\\')
		{
			if((*p) >= 'a' && (*p) <= 'z')name[j] = (*p++)-0x20;
			else name[j] = *p++;
			j++;
		}
		if(FAT_FindItem(cluster,name, &FileInfo))return 1;
		cluster = FileInfo.StartCluster;
	}
	p++;
	for(j=0;j<11;j++)name[j]=0x20;
	j=0;
	while(*p != '.')
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}
	j=8;
	p++;
	while(*p)
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}


	if(FAT_FindFreeItem(cluster,&FileInfo))return 1;
	cluster = FAT_FindFreeCluster();
	if(cluster==1)return 1;
	buffer=malloc(512);
	if(buffer==0)return 1;
	if(FAT_ReadSector(FileInfo.Sector,buffer)){free(buffer);return 1;}
	item=(struct direntry *)(&buffer[FileInfo.Offset]);

	for(j=0;j<8;j++)item->deName[j] = name[j];
	for(j=0;j<3;j++)item->deExtension[j] = name[8+j];
	item->deAttributes = ATTR_ARCHIVE;//file
	item->deLowerCase = LCASE_BASE | LCASE_EXT;
	item->deCHundredth = 0x00;
	item->deCTime[0] = 0x00;
	item->deCTime[1] = 0x60;
	item->deCDate[0] = 0x5c;
	item->deCDate[1] = 0x09;
	item->deADate[0] = 0x8e;
	item->deADate[1] = 0x35;
	item->deHighClust = cluster>>16;
	item->deMTime[0] = 0x00;
	item->deMTime[1] = 0x60;
	item->deMDate[0] = 0x50;
	item->deMDate[1] = 0x0a;
	item->deStartCluster = cluster;//the cluster number the file was stored
	item->deFileSize = size;//the file size
	if(FAT_WriteSector(FileInfo.Sector,buffer)){free(buffer);return 1;}//write the item
	free(buffer);
	if(FAT32_Enable)
	{
		if(FAT_ModifyFAT(cluster,0x0fffffff))return 1;//modify the fat table to sign that the cluster was used 
	}
	else
	{
		if(FAT_ModifyFAT(cluster,0xffff))return 1;//modify the fat table
	}
	return cluster;//reutn the first cluster number
}
//--------------------------------------------------------------------------------//
unsigned int FAT_Close(DWORD * p)
{
	*p=1;
	return 0;
}
//--------------------------------------------------------------------------------//
// Output the data of a file
// size 0 means read all of the file
unsigned char FAT_Read(DWORD pointer, DWORD size)
{
	DWORD sector;
	DWORD tempclust=pointer;
	BYTE *buffer;
	unsigned int i=0,j=0;
	sector=(DWORD)FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;
	if(size==0)size = FileInfo.Size;//whether need to read all
	printf ("%c",0x0d);
	printf ("%c",0x0a);//new line
	while(size)
	{
		buffer=malloc(512);
		if(FAT_ReadSector(sector+j,buffer)){free(buffer);return 1;}
		if(size<=512)
		{
			for(i=0;i<size;i++)
			{
				printf ("%c",buffer[i]);//output
			}
			free(buffer);
			return 0;//file over
		}
		else
		{
			for(i=0;i<512;i++)
			{
				printf ("%c",buffer[i]);
			}
			j++;
			if(j==SectorsPerClust)
			{
				j=0;
				free(buffer);
				tempclust=FAT_NextCluster(tempclust);//find the next cluster the data was stored
				if((FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0ffffff8 || tempclust == 0x0fffffff)return 1;//error
				sector=(DWORD)FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//reculculate the sector
			}
			else free(buffer);
			size-=512;
			
		}
	}
	return 0;
}
//--------------------------------------------------------------------------------//
// write data to a file
unsigned char FAT_Write(DWORD cluster,unsigned char *data,DWORD size)
{
	BYTE buffer[512];
	DWORD sector;
	unsigned int i;
	for(i=0;i<size;i++)
	{
		buffer[i]=data[i];
	}
	sector=(DWORD)FirstDataSector+(DWORD)(cluster-2)*(DWORD)SectorsPerClust;
	if(FAT_WriteSector(sector,buffer))return 1;//write the data
	return 0;
}
//--------------------------------------------------------------------------------//
//Delete a file
unsigned char FAT_Delete(BYTE *dir)
{
//	BYTE *buffer;
//	struct direntry *item;
//	WORD cluster;
	if(FAT_Open(dir)==0)return 1;//open the file
	if(FAT_DelItem(&FileInfo))return 1;//delete it
	return 0;
}
//--------------------------------------------------------------------------------//
//Delete an item
unsigned char FAT_DelItem(struct FileInfoStruct *FileInfo)
{
	BYTE *buffer;
	struct direntry *item;
	DWORD cluster;
	DWORD tempclust;
	buffer=malloc(512);
	if(buffer==0)return 1;
	if(FAT_ReadSector(FileInfo->Sector,buffer)){free(buffer);return 1;}
	item=(struct direntry *)(&buffer[FileInfo->Offset]);
	item->deName[0]=0xe5;//mark it was deleted
	if(FAT_WriteSector(FileInfo->Sector,buffer)){free(buffer);return 1;}
	free(buffer);
	cluster=FileInfo->StartCluster;
	if(FileInfo->Attr & 0x10)//if the item is a folder
	{
		while(1)
		{
			while(FAT_SelectOneItem(cluster,FileInfo)==0)
			{
				if(FAT_DelItem(FileInfo))return 1;//nest for deleting folder
			}
			tempclust=FAT_NextCluster(cluster);//if the folder contain many item
			if(tempclust==1)return 1;
			if(FAT_ModifyFAT(cluster,0))return 1;//release the fat table
			cluster=tempclust;
			if(cluster == 0x0ffffff8)return 1;//error
			if((FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0fffffff)break;//the end of the directory
		}
	}
	else// the item is a file
	{ 
		while(1)
		{
			tempclust=FAT_NextCluster(cluster);//save the next cluster
			if(tempclust==1)return 1;
			if(FAT_ModifyFAT(cluster,0))return 1;//delete curent cluster
			cluster=tempclust;
			//tempclust=FAT_NextCluster(cluster);
			if(cluster == 0x0ffffff8)return 1;//error
			if((FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0fffffff)break;//the end of the file
		}
		//if(FAT_ModifyFAT(cluster,0))return 1;//delete the final cluster
	}
	return 0;	//done
}
//--------------------------------------------------------------------------------//
//Rename a directory or a file
unsigned char FAT_Rename(BYTE *dir,BYTE *newname)
{
	BYTE name[11];
	BYTE *p=dir;
	BYTE deep=0;
	BYTE i,j;
//	BYTE directory=0;
	DWORD cluster=0;
	BYTE *buffer;
	struct direntry *item;
	if(FAT32_Enable)cluster=FirstDirClust;
	if(*p != '\\')return 1;//invalid path
	while(*p)
	{
		if(*p == '\\')
		{
			deep++;
		}
		p++;
	}
	p=dir;
	for(i=0;i<deep-1;i++)
	{
		p++;
		for(j=0;j<11;j++)name[j]=0x20;
		j=0;
		while(*p != '\\')
		{
			if((*p) >= 'a' && (*p) <= 'z')name[j] = (*p++)-0x20;
			else name[j] = *p++;
			j++;
		}
		if(FAT_FindItem(cluster,name, &FileInfo))return 1;
		cluster = FileInfo.StartCluster;
	}
	p++;
	for(j=0;j<11;j++)name[j]=0x20;
	j=0;
	while((*p != '.') && (*p) )//compatalbe for folder and file
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}
	j=8;
	if(*p == '.')//if it is a file
	{
		p++;
		while(*p)
		{
			if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
			else name[j]=*p++;
			j++;
		}
	}
	//else ;//It is a directory 
	if(FAT_FindItem(cluster,name, &FileInfo))return 1;//get the file or directory information
	buffer=malloc(512);
	if(buffer==0)return 1;
	if(FAT_ReadSector(FileInfo.Sector,buffer)){free(buffer);return 1;}//read the item according the information
	item=(struct direntry *)(&buffer[FileInfo.Offset]);

	//modify the name

	p=newname;
	for(j=0;j<11;j++)item->deName[j]=0x20;
	j=0;
	while((*p != '.') && (*p))
	{
		if(*p>='a' && *p<='z')item->deName[j]=(*p++)-0x20;
		else item->deName[j]=*p++;
		j++;
	}
	j=8;
	if(*p == '.')//if it is a file
	{
		p++;
		while(*p)
		{
			if(*p>='a' && *p<='z')item->deName[j]=(*p++)-0x20;
			else item->deName[j]=*p++;
			j++;
		}
	}
	if(FAT_WriteSector(FileInfo.Sector,buffer)){free(buffer);return 1;}//rewrite the item
	free(buffer);
	return 0;//done	
}


#endif
//--------------------------------------------------------------------------------//
//Find a item in the directory which specify by the parameter "cluster"
//Return the start cluster number
WORD FAT_FindItem(DWORD cluster, BYTE *name, struct FileInfoStruct *FileInfo)
{
	BYTE buffer[512];
	DWORD tempclust;
	DWORD sector;
	WORD cnt;
	WORD offset;
	BYTE i;
	struct direntryBytes*item = 0;
	
	if((cluster==0) && (FAT32_Enable == 0))// root directory
	{
		for(cnt=0;cnt<RootDirSectors;cnt++)
		{
			if(FAT_ReadSector(FirstDirSector+cnt,buffer)){return 1;}
			for(offset=0;offset<512;offset+=32)
			{
				item=(struct direntryBytes*)(&buffer[offset]);
				if((item->deName[0] != 0x00) && (item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
				{
					for(i=0;i<11;i++)
					{
						if(buffer[offset+i]!=name[i])break;
					}
					if(i==11)
					{
						//return the parameter of the item
						FileInfo->StartCluster = get16_little(item->deStartCluster) + (((DWORD)get16_little(item->deHighClust))<<16);//don't care
						FileInfo->Size         = get32_little(item->deFileSize);
						FileInfo->Attr         = item->deAttributes;
						FileInfo->Sector       = FirstDirSector+cnt;
						FileInfo->Offset       = offset;
						return 0;
					}
				}
			}
		}
	}
	else//other folders
	{
		tempclust=cluster;
		while(1)
		{
			sector=(DWORD)FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
			for(cnt=0;cnt<SectorsPerClust;cnt++)
			{
				if(FAT_ReadSector(sector+cnt,buffer)){return 1;}
				for(offset=0;offset<512;offset+=32)
				{
					item=(struct direntryBytes*)(&buffer[offset]);
					if((item->deName[0] != 0x00) && (item->deName[0] != 0xe5) && (item->deAttributes != 0x0f))
					{
						for(i=0;i<11;i++)
						{
							if(buffer[offset+i]!=name[i])break;
						}
						if(i==11)
						{
							FileInfo->StartCluster = get16_little(item->deStartCluster) + (((DWORD)get16_little(item->deHighClust))<<16);//don't care
							FileInfo->Size         = get32_little(item->deFileSize);							
							FileInfo->Attr         = item->deAttributes;
							FileInfo->Sector       = sector+cnt;
							FileInfo->Offset       = offset;
							return 0;
						}
					}
				}
			}
			tempclust=FAT_NextCluster(tempclust);//next cluster
			if((FAT32_Enable == 0 && tempclust == 0xffff) || tempclust == 0x0ffffff8 || tempclust == 0x0fffffff)break;
		}
	}
	return 1;
}
//--------------------------------------------------------------------------------//
// find the location with the given path
DWORD FAT_Open(BYTE * dir)
{
	BYTE name[11];
	BYTE *p=dir;
	BYTE deep=0;
	BYTE i,j;
	DWORD cluster=0;
	if(FAT32_Enable)cluster=FirstDirClust;
	if(*p != '\\')return 1;//invalid path
	while(*p)
	{
		if(*p == '\\')
		{
			deep++;
		}
		p++;
	}
	p=dir;
	for(i=0;i<deep-1;i++)
	{
		p++;
		for(j=0;j<11;j++)name[j]=0x20;
		j=0;
		while(*p != '\\')
		{
			if((*p) >= 'a' && (*p) <= 'z')name[j] = (*p++)-0x20;
			else name[j] = *p++;
			j++;
		}
		if(FAT_FindItem(cluster,name, &FileInfo))return 1;//find the directory
		cluster = FileInfo.StartCluster;
	}
	p++;
	for(j=0;j<11;j++)name[j]=0x20;
	j=0;
	while(*p != '.')//file must have a extention
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}
	j=8;
	p++;
	while(*p)
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}
	if(FAT_FindItem(cluster,name, &FileInfo))return 1;//find the file
	cluster = FileInfo.StartCluster;
	return cluster;
}
//--------------------------------------------------------------------------------//
// find a directory with the given path
DWORD FAT_OpenDir(BYTE * dir)
{
	BYTE name[11];
	BYTE *p=dir;
	BYTE deep=0;
	BYTE i,j;
	DWORD cluster=0;
	if(FAT32_Enable)cluster = FirstDirClust;
	if(*p != '\\')return 1;//invalid path
	while(*p)
	{
		if(*p == '\\')
		{
			deep++;
		}
		p++;
	}
	p=dir;
	for(i=0;i<deep-1;i++)
	{
		p++;
		for(j=0;j<11;j++)name[j]=0x20;
		j=0;
		while(*p != '\\')
		{
			if((*p) >= 'a' && (*p) <= 'z')name[j] = (*p++)-0x20;
			else name[j] = *p++;
			j++;
		}
		if(FAT_FindItem(cluster,name, &FileInfo))return 1;//find the directory
		cluster = FileInfo.StartCluster;
	}
	p++;
	for(j=0;j<11;j++)name[j]=0x20;
	j=0;
	while(*p)
	{
		if(*p>='a' && *p<='z')name[j]=(*p++)-0x20;
		else name[j]=*p++;
		j++;
	}
	if(j == 0)return cluster;
	if(FAT_FindItem(cluster,name, &FileInfo))return 1;//find the final directory
	cluster = FileInfo.StartCluster;
	return cluster;
}
//--------------------------------------------------------------------------------//
void CopyDirentruyItem(struct direntryBytes *Desti,struct direntryBytes *Source)
{
	BYTE temp;

	DWORD * i = (DWORD *)Desti;
	DWORD * j = (DWORD *)Source;
	for(temp=0;temp<8;temp++) *i++ = *j++;
}
//--------------------------------------------------------------------------------//
BYTE recordBuf[RECORD_SIZE*4];

void WriteFolderCluster(WORD addr,DWORD cluster)
{
	*(DWORD *)(&recordBuf[addr]) = cluster;
}
//--------------------------------------------------------------------------------//
DWORD GetFolderCluster(WORD addr)
{
	return *(DWORD *)(&recordBuf[addr]);
}
//--------------------------------------------------------------------------------//
BYTE SearchFolder(DWORD cluster,WORD *addr)
{
	BYTE *buffer;
	//BYTE buff[3];
	DWORD sector;
	//DWORD cluster;
	DWORD tempclust;
	BYTE cnt;
	WORD offset;
	//unsigned int i=0;
	//unsigned char j;//long name buffer offset;
//	unsigned char *p;//long name buffer pointer
	struct direntryBytes *item = 0;
	//struct winentry *we =0;
	
	if(cluster==0 && FAT32_Enable==0)// root directory
	{	
		buffer=malloc(512);//apply memory
		if(buffer==0)return 1;//if failed
		for(cnt=0;cnt<RootDirSectors;cnt++)
		{
			if(FAT_ReadSector(FirstDirSector+cnt,buffer)){free(buffer);return 1;}
			for(offset=0;offset<512;offset+=32)
			{
				item=(struct direntryBytes *)(&buffer[offset]);//pointer convert
				//find a valid item and display it
				if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
				{
					if(item->deAttributes & ATTR_DIRECTORY )
					{
//						#if FAT_DEBUG
//							printf (("\r\nFound a folder!"));
//						#endif
						if(*addr==RECORD_ADDR_END)return 0;
						else
						{
							WriteFolderCluster(*addr,get16_little(item->deStartCluster)+(((DWORD)get16_little(item->deHighClust))<<16));
							*addr+=4;
						}
					}
				}
			}
		}
		free(buffer);//release
	}
	else//other folders
	{
		tempclust=cluster;
		while(1)
		{
			sector=FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
			buffer=malloc(512);//apply memory
			if(buffer==0)return 1;//if failed
			for(cnt=0;cnt<SectorsPerClust;cnt++)
			{
				if(FAT_ReadSector(sector+cnt,buffer)){free(buffer);return 1;}
				for(offset=0;offset<512;offset+=32)
				{
					item=(struct direntryBytes *)(&buffer[offset]);
					if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
					{				
						if(item->deAttributes & ATTR_DIRECTORY )
						{
//							#if FAT_DEBUG
//								printf (("\r\nFound a folder!"));
//							#endif
							if(*addr==RECORD_ADDR_END)return 0;
							else
							{
								WriteFolderCluster(*addr,get16_little(item->deStartCluster)+(((DWORD)get16_little(item->deHighClust))<<16));
								*addr+=4;
							}
						}
					}
				}
			}
			free(buffer);//release
			tempclust=FAT_NextCluster(tempclust);//next cluster
			if(tempclust == 0x0fffffff || tempclust == 0x0ffffff8 || (FAT32_Enable == 0 && tempclust == 0xffff))break;
		}
	}
	return 0;		
}

//-------------------------------------------------------------------------------//
BYTE SearchInit()
{	
	WORD addr = RECORD_ADDR_START;
	WORD temp_addr;
	DWORD cluster;
#if FAT_DEBUG
	printf (("\r\nSearch...."));
#endif
/*
	void WriteFolderCluster(WORD addr,DWORD cluster)
{
	*(DWORD *)(&recordBuf[addr]) = cluster;
}
	
	*/
	if(FAT32_Enable)
		WriteFolderCluster(addr,FirstDirClust);//gan addr= FirstDirClust
	//neu la dinh dang  FAT32,
													//tinh dc cluster bo nho cap phat cho folder
	else 
		WriteFolderCluster(RECORD_ADDR_START,0);//dd FAT16
	
	addr += 4;//tang 4bit
	
	WriteFolderCluster(addr, 0xffffffff);

#if FAT_DEBUG
	printf (("\r\n"));
#endif
	temp_addr = addr;
	addr = RECORD_ADDR_START;
	while(1)
	{
		cluster = GetFolderCluster(addr);
		if(cluster == 0xffffffff)break;
		else
		{
			if(SearchFolder(cluster,&temp_addr))
			{
				#if FAT_DEBUG
					printf (("\r\nERROR: search folder error"));
				#endif
			}
			if(GetFolderCluster(temp_addr) != 0xffffffff)
				WriteFolderCluster(temp_addr,0XFFFFFFFF);
			if(temp_addr == RECORD_ADDR_END)
			{
			#if FAT_DEBUG
				printf (("\r\nWARNING: EEPROM is full, no more space!"));
			#endif
				WriteFolderCluster(temp_addr - 4,0XFFFFFFFF);
				break;
			}
		}
		addr+=4;
	}
	return 0;
}
//--------------------------------------------------------------------------------//
//search the file , when *count = 0 it will bring the number whole songs, when *cout != 0 the *MusicInfo will bring the infomation of the file
BYTE Search(WORD *music_record_addr,struct direntryBytes *MusicInfo,WORD *Count,BYTE *type) //��COUNTΪ��ʱ�������������Ŀ¼���ܹ��ж���������
//Search(0,&MusicInfo,&totalsongs,&type);
//struct direntryBytes MusicInfo;	// Music file information,
//32Bytes short directory record, 
//contain the short name and others //

{                            
	BYTE  tempp;
	
	
	BYTE *buffer;
	DWORD sector;
	DWORD cluster;
	DWORD tempclust;
	BYTE cnt;
	WORD offset;
	WORD i=0;
	BYTE j;//long name buffer offset;
	BYTE *p;//long name buffer pointer
	struct direntryBytes *item = 0;
	struct winentryBytes *we =0;
		
	WORD addr = RECORD_ADDR_START;
	//#define  RECORD_SIZE 256	
	//#define  RECORD_ADDR_START 0
	while(1)
	{
		
/*
DWORD GetFolderCluster(WORD addr)
{
	return *(DWORD *)(&recordBuf[addr]);
}		
*/
		cluster = GetFolderCluster(addr);
		addr += 4;
		if(cluster == 0xffffffff)break;
		else //1
		{
//			if(music_record_addr != 0) 
//				*music_record_addr = addr - 4;	/* record in which record found the right file */
			
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX				
			//lam toi day, search
			//y tuong la gan cho 1 mang con tro moi
			if(cluster!=0 && FAT32_Enable!=0)
		//other folders
			{
				tempclust=cluster;
				while(1)
				{
					sector=FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
					//SectorsPerClust sector trong folder
					buffer=malloc(512);//apply memory
					if(buffer==0)return 1;//if failed
					for(cnt=0;cnt<SectorsPerClust;cnt++)
					{
						if(FAT_ReadSector(sector+cnt,buffer)){free(buffer);return 1;}
						for(offset=0;offset<512;offset+=32)
						{
							item=(struct direntryBytes *)(&buffer[offset]);
					if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
							{				
					
								if(item->deAttributes == 0x0f)
								{
										we = (struct winentryBytes *)(&buffer[offset]);
									j = 26*( (we->weCnt-1) & WIN_CNT);//???
        /* */   			  if(j<MAX_LONG_NAME_SIZE-25)
							//			if(j<MAX_LONG_NAME_SIZE)//ko co so -25 thi luon mo 1 bai cuoi cung
										//lay ten file vao LongNameBuffer[]
							    {
										  p = &LongNameBuffer[j];
									    for (j=0;j<10;j++)	*p++ = we->wePart1[j];			
									    for (j=0;j<12;j++)	*p++ = we->wePart2[j];
									    for (j=0;j<4;j++)	*p++ = we->wePart3[j];	
									    if ((we->weCnt & WIN_CNT) == 1)LongNameFlag = 1;
										}							
								}

								else if((item->deExtension[0] == 'M')&&(item->deExtension[1] == 'P')&&(item->deExtension[2] == '3'))
								{
								if (dis)
								{
								#if FAT_DEBUG
									printf ("\r\n%03d ",i+1);
									if (LongNameFlag)
									{ 	
										for (tempp = 0;tempp < MAX_LONG_NAME_SIZE;tempp++)
										{
											if (LongNameBuffer[tempp] == '.')
											{	
												break;
											}
											printf ("%c",LongNameBuffer[tempp]);
											//gan vao mang prin o day
											LongName_in[tempp]=LongNameBuffer[tempp];
											
										}
										printf (".mp3");
									}
									else
									{
										for(j=0;j<8;j++)
											printf ("%c",item->deName[j]);
											
										printf ("%c",'.');
										for(j=0;j<3;j++)
											printf ("%c",item->deExtension[j]);
											
									
									}
								#endif
								}
									CopyDirentruyItem(MusicInfo,item);
									*type = 1;
									i++;
									if(i==*Count){free(buffer);return 0;}
									else LongNameFlag = 0;	
								}
								else LongNameFlag = 0;
							}
						}
					}
					free(buffer);//release
					
					
					tempclust=FAT_NextCluster(tempclust);//next cluster
					if(tempclust == 0x0fffffff || tempclust == 0x0ffffff8 || (FAT32_Enable == 0 && tempclust == 0xffff))break;
				}//END while(1) 2 
			}//END if other folders

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX		


		}//END else 1
	}//XXXXXXXXXX //END WHILE(1)  1


	if(*Count==0)*Count=i;
	return 0;	
}
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

//search the file 
BYTE SearchLrc(BYTE *dir,BYTE * longnamebuffer,struct direntryBytes *LrcInfo,WORD music_record_addr)
{                                                         
	BYTE *buffer;
	BYTE longbuffertemp[130];
	BYTE * p1, * p2;
	BYTE match = 0;
	DWORD sector;
	DWORD cluster;
	DWORD tempclust;
	BYTE i;
	BYTE cnt;
	WORD offset;
	//unsigned int i=0;
	BYTE j;//long name buffer offset;
	BYTE *p;//long name buffer pointer
	struct direntryBytes *item = 0;
	struct winentryBytes *we =0;
	
	//cluster = FAT_OpenDir(dir);
	//if(cluster == 1)return 1;

	
//#if FAT_DEBUG
//	printf (("music_record_addr = %d\r\n"),music_record_addr);
//#endif
	
	for(i=0;i<2;i++)
	{
		if(i==0)cluster = GetFolderCluster(music_record_addr);		/* the same folder where the music file placed */
		else	cluster = FAT_OpenDir(dir);	/* search the default lyric folder */
		if(cluster == 1)return 1;
		if(cluster==0 && FAT32_Enable==0)// root directory
		{
			buffer=malloc(512);//apply memory
			if(buffer==0)return 1;//if failed
			for(cnt=0;cnt<RootDirSectors;cnt++)
			{
				if(FAT_ReadSector(FirstDirSector+cnt,buffer)){free(buffer);return 1;}
				for(offset=0;offset<512;offset+=32)
				{
					item=(struct direntryBytes*)(&buffer[offset]);//pointer convert
					//find a valid item and display it
					if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
					{
						if(item->deAttributes == 0x0f)
						{
							we = (struct winentryBytes*)(&buffer[offset]);
							j = 26 *( (we->weCnt-1) & WIN_CNT);
							if(j<MAX_LONG_NAME_SIZE-25)
							{
								p = &longbuffertemp[j];
								for (j=0;j<10;j++)	*p++ = we->wePart1[j];			
								for (j=0;j<12;j++)	*p++ = we->wePart2[j];
								for (j=0;j<4;j++)	*p++ = we->wePart3[j];	
								if (we->weCnt & 0x40) (*(WORD *)p) = 0;				
								if ((we->weCnt & WIN_CNT) == 1) LongNameFlag = 1;	
							}
							longbuffertemp[MAX_LONG_NAME_SIZE-1] = 0;
							longbuffertemp[MAX_LONG_NAME_SIZE-2] = 0;
						}
						else if((item->deExtension[0] == 'L')&&(item->deExtension[1] == 'R')&&(item->deExtension[2] == 'C'))
						{
							CopyDirentruyItem(LrcInfo,item);
							p1 = longnamebuffer;
							p2 = longbuffertemp;
							match = 1; 
							if(LongNameFlag)
							{
								while(*((WORD*)p1))
								{
									if(*(WORD*)p1 != *(WORD*)p2)
									{
										match = 0;
										break;
									}
										p1 += 2;
									p2 += 2;	
								}
							}
							else
							{
								p2 = item->deName;
								while(*p1)
								{
									if(*p1++ != *p2++)
									{
										match = 0;
										break;
									}
								}
							}
							if(match){free(buffer);return 0;}
							else LongNameFlag = 0;	
						}
						else LongNameFlag = 0;
					}
				}
			}
			free(buffer);//release
		}
		else//other folders
		{
			tempclust=cluster;
			while(1)
			{
				sector=FirstDataSector+(DWORD)(tempclust-2)*(DWORD)SectorsPerClust;//calculate the actual sector number
				buffer=malloc(512);//apply memory
				if(buffer==0)return 1;//if failed
				for(cnt=0;cnt<SectorsPerClust;cnt++)
				{
					if(FAT_ReadSector(sector+cnt,buffer)){free(buffer);return 1;}
					for(offset=0;offset<512;offset+=32)
					{
						item=(struct direntryBytes *)(&buffer[offset]);
						if((item->deName[0] != '.') && (item->deName[0] != 0x00) && (item->deName[0] != 0xe5))
						{				
							if(item->deAttributes == 0x0f)
							{
								we = (struct winentryBytes *)(&buffer[offset]);
								j = 26 *( (we->weCnt-1) & WIN_CNT);
								if(j<MAX_LONG_NAME_SIZE-25)
								{
									p = &longbuffertemp[j];
									for (j=0;j<10;j++)	*p++ = we->wePart1[j];			
									for (j=0;j<12;j++)	*p++ = we->wePart2[j];
									for (j=0;j<4;j++)	*p++ = we->wePart3[j];	
									if (we->weCnt & 0x40) (*(WORD *)p) = 0;				
									if ((we->weCnt & WIN_CNT) == 1) LongNameFlag = 1;	
								}
								longbuffertemp[MAX_LONG_NAME_SIZE-1] = 0;
								longbuffertemp[MAX_LONG_NAME_SIZE-2] = 0;
							}
							else if((item->deExtension[0] == 'L')&&(item->deExtension[1] == 'R')&&(item->deExtension[2] == 'C'))
							{
								CopyDirentruyItem(LrcInfo,item);
								p1 = longnamebuffer;
								p2 = longbuffertemp;
								match = 1; 
								if(LongNameFlag)
								{
										while(*((WORD*)p1))
										{
										if(*(WORD*)p1 != *(WORD*)p2)
										{
											match = 0;
											break;
										}
										p1 += 2;
										p2 += 2;	
									}
								}
								else
								{
									p2 = item->deName;
									while(*p1)
									{
										if(*p1++ != *p2++)
										{
											match = 0;
											break;
										}
									}
								}
								if(match){free(buffer);return 0;}
								else LongNameFlag = 0;	
							}
							else LongNameFlag = 0;
						}	
					}
				}
				free(buffer);//release
				tempclust=FAT_NextCluster(tempclust);//next cluster
				if(tempclust == 0x0fffffff || tempclust == 0x0ffffff8 || (FAT32_Enable == 0 && tempclust == 0xffff))break;
			}
		}
	}
	return 1;	/*can't find lrc file*/
}
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//



#endif
