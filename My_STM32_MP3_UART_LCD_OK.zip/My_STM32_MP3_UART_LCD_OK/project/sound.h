#define sound0_size 15054

extern unsigned char sound0[];
extern void test_sound (void);


