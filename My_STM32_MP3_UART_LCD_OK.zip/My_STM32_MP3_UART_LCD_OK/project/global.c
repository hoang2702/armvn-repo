#include "global.h"

WORD get16(BYTE * addr)
{
	WORD temp;
#if defined(BIG_ENDIAN)
	temp = *addr;
	temp <<= 8;
	temp += *(addr+1);
#else
	temp = *(addr+1);
	temp <<= 8;
	temp += *addr;
#endif
	return temp;
}

DWORD get32(BYTE * addr)
{
	DWORD temp;
#if defined(BIG_ENDIAN)
	temp = *addr;
	temp <<= 8;
	temp += *(addr+1);
	temp <<= 8;
	temp += *(addr+2);
	temp <<= 8;
	temp += *(addr+3);
#else
	temp = *(addr+3);
	temp <<= 8;
	temp += *(addr+2);
	temp <<= 8;
	temp += *(addr+1);
	temp <<= 8;
	temp += *addr;
#endif
	return temp;
}

WORD get16_little(BYTE * addr)
{
	WORD temp;

	temp = *(addr+1);
	temp <<= 8;
	temp += *addr;

	return temp;
}

DWORD get32_little(BYTE * addr)
{
	DWORD temp;

	temp = *(addr+3);
	temp <<= 8;
	temp += *(addr+2);
	temp <<= 8;
	temp += *(addr+1);
	temp <<= 8;
	temp += *addr;

	return temp;
}

WORD get16_big(BYTE * addr)
{
	WORD temp;

	temp = *addr;
	temp <<= 8;
	temp += *(addr+1);

	return temp;
}

DWORD get32_big(BYTE * addr)
{
	DWORD temp;

	temp = *addr;
	temp <<= 8;
	temp += *(addr+1);
	temp <<= 8;
	temp += *(addr+2);
	temp <<= 8;
	temp += *(addr+3);

	return temp;
}


void put16(BYTE * addr, WORD val)
{
#if defined(BIG_ENDIAN)
	*addr = val>>8;
	*(addr+1) = val;
#else
	*addr = val;
	*(addr+1) = val>>8;
#endif
}

void put32(BYTE * addr,DWORD val)
{
#if defined(BIG_ENDIAN)
	*addr = val>>24;
	*(addr+1) = val>>16;
	*(addr+2) = val>>8;
	*(addr+3) = val;
#else
	*addr = val;
	*(addr+1) = val>>8;
	*(addr+2) = val>>16;
	*(addr+3) = val>>24;
#endif
}

void put16_little(BYTE * addr, WORD val)
{
	*addr = val;
	*(addr+1) = val>>8;
}

void put32_little(BYTE * addr,DWORD val)
{
	*addr = val;
	*(addr+1) = val>>8;
	*(addr+2) = val>>16;
	*(addr+3) = val>>24;
}


void put16_big(BYTE * addr, WORD val)
{
	*addr = val>>8;
	*(addr+1) = val;
}

void put32_big(BYTE * addr,DWORD val)
{
	*addr = val>>24;
	*(addr+1) = val>>16;
	*(addr+2) = val>>8;
	*(addr+3) = val;
}


WORD swap16(WORD val)
{
	WORD temp;
	
	temp = val;
	temp <<=8;
	temp += val>>8;
	
	return temp;
}

DWORD swap32(DWORD val)
{
	DWORD temp;
	
	temp = val;
	temp <<=8;
	temp += val>>8;
	temp <<=8;
	temp += val>>16;
	temp <<=8;
	temp += val>>24;

	return temp;
}


void soft_delay_ms(uint32 t)
{
	uint32 i,j;
	for(i=0;i<=t;i++)
		for(j=0;j<8000;j++);
}

#if 1

void dump_memory(unsigned char * addr, unsigned int length)
{
	unsigned char * p = addr;
	unsigned int i,j;
	unsigned int ii,jj;
	ii = length/16;
	jj = length%16;
	
	iprintf("_____________________________________________________\r\n");
	iprintf("ADDR  00 01 02 03 04 05 06 07-08 09 0a 0b 0c 0d 0e 0f \r\n");
	iprintf("-----------------------------------------------------\r\n");
	for(i=0;i<32;i++)
	{
		iprintf("%04x: ",i*16);
		for(j=0;j<16;j++)
		{
			if(i==ii && j==jj)break;
			if(j==7)iprintf("%02x-",*p++);
			else iprintf("%02x ",*p++);
		}
		iprintf("\r\n");
		if(i==ii && j==jj)break;
	}
	iprintf("-----------------------------------------------------\r\n");	
}
#endif
