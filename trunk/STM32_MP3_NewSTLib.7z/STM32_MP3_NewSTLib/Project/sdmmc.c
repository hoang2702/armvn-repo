#include 	"stm32f10x.h"
#include 	"platform_config.h"

#ifndef __SDMMC_C
#define __SDMMC_C

#include 	"stdio.h"
#include 	"uart.h"
#include 	"sdmmc.h"

#define BYTE_MODE   0
#define BLOCK_MODE  1

static uint8 address_mode = BYTE_MODE;


//--------------------------------------------------------------------------//
void spi_init (void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    SPI_InitTypeDef   SPI_InitStructure;
     /* GPIOA and GPIOC Periph clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |RCC_APB2Periph_GPIOC, ENABLE);
    /* SPI1 Periph clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

    /* Configure SPI2 pins: SCK, MISO and MOSI */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC , ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);


    SPI_I2S_DeInit(SPI1);
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);

    /* SPI1 enable */
    SPI_Cmd(SPI1, ENABLE);
}
//--------------------------------------------------------------------------//
// read and write one byte , full duplex 
uint8 SPI_WriteByte (uint8 val)
{
	/* Write in the DR register the data to be sent */
  	SPI1->DR = val;
		while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
 	return SPI1->DR;
}
//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
// sd send command 
uint8 MMC_SD_SendCommand (uint8 cmd, uint32 arg)
{
	uint8 r1;
	uint16 retry=0;

	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_CS_Assert;
	
	SPI_WriteByte(cmd | 0x40);	/* send command */
	SPI_WriteByte(arg>>24);
	SPI_WriteByte(arg>>16);
	SPI_WriteByte(arg>>8);
	SPI_WriteByte(arg);
	SPI_WriteByte(0x95);
	
	while((r1 = SPI_WriteByte(0xff)) == 0xff)	/* wait response */
		if(retry++ > CMD_TIMOUT) break;				/* time out error */

	SPI_CS_Deassert;
	SPI_WriteByte(0xff);				// extra 8 CLK


	return r1;								/* return state */
}

/* sd send command */ 
uint8 MMC_SD_SendCommandCRC_NoDeassert(uint8 cmd, uint32 arg)
{
	uint8 r1;
	uint16 retry=0;

	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_CS_Assert;
	
	SPI_WriteByte(cmd | 0x40);	/* send command */
	SPI_WriteByte(arg>>24);
	SPI_WriteByte(arg>>16);
	SPI_WriteByte(arg>>8);
	SPI_WriteByte(arg);
	SPI_WriteByte(0x95);
	
	while((r1 = SPI_WriteByte(0xff)) == 0xff)	/* wait response */
		if(retry++ > CMD_TIMOUT) break;			/* time out error */

	return r1;									/* return state */
}
//-----------------------------------------------------------------------------//
// SD card initialization, include reset and configuration */
uint8 MMC_SD_Init(void)
{
	uint8 i;
	uint16 retry = 0;
	uint8 r1 = 0;

	uint8 buffer[4];
	
	spi_init ();
	

	printf ("\r\nINIT SD/MMC");
	SPI_CS_Deassert;
 	
	for(i=0;i<10;i++) 
			SPI_WriteByte(0xff);

	do
	{
		r1 = MMC_SD_SendCommand(0, 0);/*send idle command*/
			retry++;
		if(retry>CMD_TIMOUT) return 1;/*time out*/
	} while(r1 != 0x01);
	
	printf ("\r\nAfter Send CMD");
	printf ("\r\nVersion 2.");
	
	SPI_CS_Deassert;
	SPI_WriteByte(0xff);				/* extra 8 CLK */
	retry = 0;

/*	MMC_SD_SendCommandCRC_NoDeassert(58, 0);	 		//Read OCR;
	SPI_WriteByte (0xff);
	SPI_WriteByte (0xff);
	SPI_WriteByte (0xff);
	SPI_WriteByte (0xff);
 */
	do
	{
		r1 = MMC_SD_SendCommand(55, 0);
		printf ("\r\nR1 = %02x",r1);
		if(r1 != 0x01)
		{
			return r1;
		}
		r1 = MMC_SD_SendCommandCRC_NoDeassert(41, 0x40000000);
	
	} while (r1 & 0x01);
	/*
	printf ("\r\nResponse R1 %02x",r1);
	if (r1 == 0x01)
	{	
		printf ("\r\nHold");
		while (1);
	}
	//}while(r1!=0);
	*/
	if(MMC_SD_SendCommandCRC_NoDeassert(58, 0)!=0x00)
	{
			SPI_CS_Deassert;
			SPI_WriteByte(0xff);	//			 extra 8 CLK 
			return 1;	
	}
	else
	{
	
		for(i=0;i<4;i++)
			buffer[i]=SPI_WriteByte(0xff);

		if(buffer[0]&(1<<6))
			address_mode = BLOCK_MODE;
		else
			address_mode = BYTE_MODE;
		
		SPI_CS_Deassert;
		SPI_WriteByte(0xff);				/* extra 8 CLK */
		return 0; 			/*normal return*/
	}
}
//--------------------------------------------------------------------------//

//read one sector
uint8 MMC_SD_ReadSingleBlock(uint32 sector, uint8* buffer)
{
	uint8 r1;
	uint16 i;
	uint32 retry=0;

	//SPI_High();		/* Use High Speed SPI*/

	r1 = MMC_SD_SendCommandCRC_NoDeassert(17, address_mode?sector:sector<<9);//������	//read command
	
	if(r1 != 0x00)
		return r1;

	SPI_CS_Assert;

	while(SPI_WriteByte(0xff) != 0xfe)

	if(retry++ > ACCESS_TIMEOUT)
	{
		SPI_CS_Deassert;
		return 1;
	}

	for(i=0; i<512; i++)//��512������	//read 512 bytes
	{
		*buffer++ = SPI_WriteByte(0xff);
	}

	SPI_WriteByte(0xff);//αcrc    //dummy crc
	SPI_WriteByte(0xff);
	
	SPI_CS_Deassert;
	SPI_WriteByte(0xff);// extra 8 CLK

	return 0;
}


		//wirite one sector //not used in this application
uint8 MMC_SD_WriteSingleBlock(uint32 sector, uint8* buffer)
{
	uint8 r1;
	uint16 i;
	uint32 retry=0;
	
	//SPI_High();		/* Use High Speed SPI*/

	r1 = MMC_SD_SendCommandCRC_NoDeassert(24,  address_mode?sector:sector<<9);//д����	//send command
	if(r1 != 0x00)
		return r1;

	SPI_CS_Assert;
	
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);

	SPI_WriteByte(0xfe);//����ʼ��			//send start byte "token"
	
	for(i=0; i<512; i++)//��512�ֽ�����		//send 512 bytes data
	{
		SPI_WriteByte(*buffer++);
	}
	
	SPI_WriteByte(0xff);			//dummy crc
	SPI_WriteByte(0xff);
	
	r1 = SPI_WriteByte(0xff);
	
	if( (r1&0x1f) != 0x05)//�ȴ��Ƿ�ɹ�	//judge if it successful
	{
		SPI_CS_Deassert;
		return r1;
	}
	//�ȴ�������		//wait no busy
	while(!SPI_WriteByte(0xff))if(retry++ > ACCESS_TIMEOUT){SPI_CS_Deassert;return 1;}

	SPI_CS_Deassert;
	SPI_WriteByte(0xff);// extra 8 CLK

	return 0;
}


/* return number of max block, in case of 512bytes per unit */
uint32 MMC_SD_ReadCapacity()
{
	uint8 r1;
	uint16 i;
	uint16 temp;
	uint8 buffer[16];
	uint32 Capacity;
	uint32 retry =0;
	//uint8 retry=0;

	//if(address_mode==BLOCK_MODE) return 0; /*currently I do not have the spec. so do not kown how to calculate the capacity*/
	
	//SPI_High();		/* Use High Speed SPI*/

	r1 = MMC_SD_SendCommandCRC_NoDeassert(9, 0);//д����	//send command  //READ CSD
	if(r1 != 0x00)
		return r1;

	SPI_CS_Assert;
	while(SPI_WriteByte(0xff) != 0xfe)if(retry++ > ACCESS_TIMEOUT){SPI_CS_Deassert;return 1;}

	
	for(i=0;i<16;i++)
	{
		buffer[i]=SPI_WriteByte(0xff);
	}	

	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	
	SPI_WriteByte(0xff);
	
	SPI_CS_Deassert;

	SPI_WriteByte(0xff);// extra 8 CLK

	if((buffer[0]&0xc0)==0x40)
	{
		Capacity =  (((uint32)buffer[8])<<8 + (uint32)buffer[9] +1)*(uint32)1024;
		return Capacity;
	}

/*********************************/
//	C_SIZE
	i = buffer[6]&0x03;
	i<<=8;
	i += buffer[7];
	i<<=2;
	i += ((buffer[8]&0xc0)>>6);

/**********************************/
//  C_SIZE_MULT

	r1 = buffer[9]&0x03;
	r1<<=1;
	r1 += ((buffer[10]&0x80)>>7);


/**********************************/
// BLOCKNR

	r1+=2;

	temp = 1;
	while(r1)
	{
		temp*=2;
		r1--;
	}
	
	Capacity = ((uint32)(i+1))*((uint32)temp);

/////////////////////////
// READ_BL_LEN

	i = buffer[5]&0x0f;

/*************************/
//BLOCK_LEN

	temp = 1;
	while(i)
	{
		temp*=2;
		i--;
	}
/************************/


/************** formula of the capacity ******************/
//
//  memory capacity = BLOCKNR * BLOCK_LEN
//	
//	BLOCKNR = (C_SIZE + 1)* MULT
//
//           C_SIZE_MULT+2
//	MULT = 2
//
//               READ_BL_LEN
//	BLOCK_LEN = 2
/**********************************************/

//The final result
	
	Capacity *= (uint32)temp;	 
	return Capacity/512;		
}


//--------------------------------------------------------------------------//
//--------------------------------------------------------------------------//
#endif
