#ifndef __FAT_H__
#define __FAT_H__

#include 	"global.h"
#include    <stdlib.h>

#define FAT_BUFFERED 1

#define MAX_LONG_NAME_SIZE 80		/* 26*n+2   n=3 */
#define FAT_DEBUG 			1		/* FAT debug flag */

#if FAT_DEBUG
	#define FAT_DBG_Printf printf
	#define FAT_DBG_Putc uart0_putc
#endif


#define FIX_DIRECTORY 0		/* 1 means use fix directory, 0 for any directory */


#if FIX_DIRECTORY==0

	#define  RECORD_SIZE 256	
	#define  RECORD_ADDR_START 0	/* eeprom start address */
	#define  RECORD_ADDR_END  RECORD_SIZE*4	/* eeprom end address */
	
#endif


extern BYTE (* FAT_ReadSector)(DWORD,BYTE *);
extern BYTE (* FAT_WriteSector)(DWORD,BYTE *);
extern DWORD (* FAT_ReadCapacity)(void);


extern BYTE MMC_SD_ReadSingleBlock(DWORD sector, BYTE* buffer);
extern BYTE MMC_SD_WriteSingleBlock(DWORD sector, BYTE* buffer);

extern DWORD MMC_SD_ReadCapacity(void);



#define MSDOSFSROOT     0               // cluster 0 means the root dir
#define CLUST_FREE      0               // cluster 0 also means a free cluster
#define MSDOSFSFREE     CLUST_FREE
#define CLUST_FIRST     2             	// first legal cluster number
#define CLUST_RSRVD     0xfff6      	// reserved cluster range
#define CLUST_BAD       0xfff7     		// a cluster with a defect
#define CLUST_EOFS      0xfff8     		// start of eof cluster range
#define CLUST_EOFE      0xffff      	// end of eof cluster range

struct  partrecord// length 16 bytes
{			
	BYTE	prIsActive;					// 0x80 indicates active partition
	BYTE	prStartHead;				// starting head for partition
	WORD	prStartCylSect;				// starting cylinder and sector
	BYTE	prPartType;					// partition type (see above)
	BYTE	prEndHead;					// ending head for this partition
	WORD	prEndCylSect;				// ending cylinder and sector
	DWORD	prStartLBA;					// first LBA sector for this partition
	DWORD	prSize;						// size of this partition (bytes or sectors ?)
};
typedef struct partrecord partrecord;

struct partrecordBytes // length 16 bytes
{			
	BYTE	prIsActive;					// 0x80 indicates active partition
	BYTE	prStartHead;				// starting head for partition
	BYTE	prStartCylSect[2];			// starting cylinder and sector
	BYTE	prPartType;					// partition type (see above)
	BYTE	prEndHead;					// ending head for this partition
	BYTE	prEndCylSect[2];				// ending cylinder and sector
	BYTE	prStartLBA[4];				// first LBA sector for this partition
	BYTE	prSize[4];					// size of this partition (bytes or sectors ?)
};
typedef struct partrecordBytes partrecordBytes;
        
struct partsector
{
	CHAR	psPartCode[512-64-2];		// pad so struct is 512b
	BYTE	psPart[64];					// four partition records (64 bytes)
	BYTE	psBootSectSig0;				// two signature bytes (2 bytes)
	BYTE	psBootSectSig1;
#define BOOTSIG0        0x55
#define BOOTSIG1        0xaa
};
typedef struct partsector partsector;

struct extboot
{
	CHAR	exDriveNumber;				// drive number (0x80)//0x00 for floopy disk 0x80 for hard disk
	CHAR	exReserved1;				// reserved should always set 0
	CHAR	exBootSignature;			// ext. boot signature (0x29)
#define EXBOOTSIG       0x29
	CHAR	exVolumeID[4];				// volume ID number
	CHAR	exVolumeLabel[11];			// volume label "NO NAME"
	CHAR	exFileSysType[8];			// fs type (FAT12 or FAT)
};
typedef struct extboot extboot;

struct bootsector50
{
	BYTE	bsJump[3];					// jump inst E9xxxx or EBxx90
	CHAR	bsOemName[8];				// OEM name and version
	CHAR	bsBPB[25];					// BIOS parameter block
	CHAR	bsExt[26];					// Bootsector Extension
	CHAR	bsBootCode[448];			// pad so structure is 512b
	BYTE	bsBootSectSig0;				// boot sector signature byte 0x55 
	BYTE	bsBootSectSig1;				// boot sector signature byte 0xAA
#define BOOTSIG0        0x55
#define BOOTSIG1        0xaa
};
typedef struct bootsector50 bootsector50;


struct bpb50 
{
        WORD	bpbBytesPerSec; // bytes per sector				//512 1024 2048 or 4096
        BYTE	bpbSecPerClust; // sectors per cluster			// power of 2
        WORD	bpbResSectors;  // number of reserved sectors	//1 is recommend
        BYTE	bpbFATs;        // number of FATs				// 2 is recommend
        WORD	bpbRootDirEnts; // number of root directory entries
        WORD	bpbSectors;     // total number of sectors
        BYTE	bpbMedia;       // media descriptor				//0xf8 match the fat[0]
        WORD	bpbFATsecs;     // number of sectors per FAT
        WORD	bpbSecPerTrack; // sectors per track
        WORD	bpbHeads;       // number of heads
        DWORD	bpbHiddenSecs;  // # of hidden sectors
        DWORD	bpbHugeSectors; // # of sectors if bpbSectors == 0
};
typedef struct bpb50 bpb50;

struct bootsector710 
{
	BYTE	bsJump[3];					// jump inst E9xxxx or EBxx90
	CHAR	bsOemName[8];				// OEM name and version
	CHAR	bsBPB[53];					// BIOS parameter block
	CHAR	bsExt[26];					// Bootsector Extension
	CHAR	bsBootCode[418];			// pad so structure is 512b
	BYTE	bsBootSectSig2;				// boot sector signature byte 0x00 
	BYTE	bsBootSectSig3;				// boot sector signature byte 0x00
	BYTE	bsBootSectSig0;				// boot sector signature byte 0x55 
	BYTE	bsBootSectSig1;				// boot sector signature byte 0xAA
#define BOOTSIG0        0x55
#define BOOTSIG1        0xaa
#define BOOTSIG2        0x00
#define BOOTSIG3        0x00
};
typedef struct bootsector710 bootsector710;

struct bpb710 
{
		WORD	bpbBytesPerSec;	// bytes per sector
		BYTE	bpbSecPerClust;	// sectors per cluster
		WORD	bpbResSectors;	// number of reserved sectors
		BYTE	bpbFATs;		// number of FATs
		WORD	bpbRootDirEnts;	// number of root directory entries
		WORD	bpbSectors;		// total number of sectors
		BYTE	bpbMedia;		// media descriptor
		WORD	bpbFATsecs;		// number of sectors per FAT
		WORD	bpbSecPerTrack;	// sectors per track
		WORD	bpbHeads;		// number of heads
		DWORD	bpbHiddenSecs;	// # of hidden sectors
// 3.3 compat ends here
		DWORD	bpbHugeSectors;	// # of sectors if bpbSectors == 0
// 5.0 compat ends here
		DWORD     bpbBigFATsecs;// like bpbFATsecs for FAT32
		WORD      bpbExtFlags;	// extended flags:
#define FATNUM    0xf			// mask for numbering active FAT
#define FATMIRROR 0x80			// FAT is mirrored (like it always was)
		WORD      bpbFSVers;	// filesystem version
#define FSVERS    0				// currently only 0 is understood
		DWORD     bpbRootClust;	// start cluster for root directory
		WORD      bpbFSInfo;	// filesystem info structure sector
		WORD      bpbBackup;	// backup boot sector
		// There is a 12 byte filler here, but we ignore it
};
typedef struct bpb710 bpb710;

struct bpb710Bytes 
{
		BYTE	bpbBytesPerSec[2];	// bytes per sector
		BYTE	bpbSecPerClust;	// sectors per cluster
		BYTE	bpbResSectors[2];	// number of reserved sectors
		BYTE	bpbFATs;		// number of FATs
		BYTE	bpbRootDirEnts[2];	// number of root directory entries
		BYTE	bpbSectors[2];		// total number of sectors
		BYTE	bpbMedia;		// media descriptor
		BYTE	bpbFATsecs[2];		// number of sectors per FAT
		BYTE	bpbSecPerTrack[2];	// sectors per track
		BYTE	bpbHeads[2];		// number of heads
		BYTE	bpbHiddenSecs[4];	// # of hidden sectors
// 3.3 compat ends here
		BYTE	bpbHugeSectors[4];	// # of sectors if bpbSectors == 0
// 5.0 compat ends here
		BYTE     bpbBigFATsecs[4];// like bpbFATsecs for FAT32
		BYTE      bpbExtFlags[2];	// extended flags:
#define FATNUM    0xf			// mask for numbering active FAT
#define FATMIRROR 0x80			// FAT is mirrored (like it always was)
		BYTE      bpbFSVers[2];	// filesystem version
#define FSVERS    0				// currently only 0 is understood
		BYTE     bpbRootClust[4];	// start cluster for root directory
		BYTE      bpbFSInfo[2];	// filesystem info structure sector
		BYTE      bpbBackup[2];	// backup boot sector
		// There is a 12 byte filler here, but we ignore it  
};
typedef struct bpb710Bytes bpb710Bytes;


// Structure of a dos directory entry.
struct direntry 
{
		BYTE		deName[8];      	// filename, blank filled
#define SLOT_EMPTY      0x00            // slot has never been used
#define SLOT_E5         0x05            // the real value is 0xE5
#define SLOT_DELETED    0xE5            // file in this slot deleted
#define SLOT_DIR		0x2E			// a directorymmm
		BYTE		deExtension[3]; 	// extension, blank filled
		BYTE		deAttributes;   	// file attributes
#define ATTR_NORMAL     0x00            // normal file
#define ATTR_READONLY   0x01            // file is readonly
#define ATTR_HIDDEN     0x02            // file is hidden
#define ATTR_SYSTEM     0x04            // file is a system file
#define ATTR_VOLUME     0x08            // entry is a volume label
#define ATTR_LONG_FILENAME	0x0F		// this is a long filename entry			    
#define ATTR_DIRECTORY  0x10            // entry is a directory name
#define ATTR_ARCHIVE    0x20            // file is new or modified
		BYTE        deLowerCase;    	// NT VFAT lower case flags  (set to zero)
#define LCASE_BASE      0x08            // filename base in lower case
#define LCASE_EXT       0x10            // filename extension in lower case
		BYTE        deCHundredth;   	// hundredth of seconds in CTime
		BYTE        deCTime[2];     	// create time
		BYTE        deCDate[2];     	// create date
		BYTE        deADate[2];     	// access date
		WORD        deHighClust; 		// high bytes of cluster number
		BYTE        deMTime[2];     	// last update time
		BYTE        deMDate[2];     	// last update date
		WORD        deStartCluster; 	// starting cluster of file
		DWORD       deFileSize;  		// size of file in bytes
};
typedef struct direntry direntry;

// Structure of a dos directory entry.
struct direntryBytes 
{
		BYTE		deName[8];      	// filename, blank filled
#define SLOT_EMPTY      0x00            // slot has never been used
#define SLOT_E5         0x05            // the real value is 0xE5
#define SLOT_DELETED    0xE5            // file in this slot deleted
#define SLOT_DIR		0x2E			// a directorymmm
		BYTE		deExtension[3]; 	// extension, blank filled
		BYTE		deAttributes;   	// file attributes
#define ATTR_NORMAL     0x00            // normal file
#define ATTR_READONLY   0x01            // file is readonly
#define ATTR_HIDDEN     0x02            // file is hidden
#define ATTR_SYSTEM     0x04            // file is a system file
#define ATTR_VOLUME     0x08            // entry is a volume label
#define ATTR_LONG_FILENAME	0x0F		// this is a long filename entry			    
#define ATTR_DIRECTORY  0x10            // entry is a directory name
#define ATTR_ARCHIVE    0x20            // file is new or modified
		BYTE        deLowerCase;    	// NT VFAT lower case flags  (set to zero)
#define LCASE_BASE      0x08            // filename base in lower case
#define LCASE_EXT       0x10            // filename extension in lower case
		BYTE        deCHundredth;   	// hundredth of seconds in CTime
		BYTE        deCTime[2];     	// create time
		BYTE        deCDate[2];     	// create date
		BYTE        deADate[2];     	// access date
		BYTE        deHighClust[2]; 		// high bytes of cluster number
		BYTE        deMTime[2];     	// last update time
		BYTE        deMDate[2];     	// last update date
		BYTE        deStartCluster[2]; 	// starting cluster of file
		BYTE        deFileSize[4];  		// size of file in bytes
};
typedef struct direntryBytes direntryBytes;

// number of directory entries in one sector
#define DIRENTRIES_PER_SECTOR	0x10	//when the bpbBytesPerSec=512 

// Structure of a Win95 long name directory entry
struct winentry
{
		BYTE			weCnt;			// 
#define WIN_LAST        0x40
#define WIN_CNT         0x3f
		BYTE		wePart1[10];
		BYTE		weAttributes;
#define ATTR_WIN95      0x0f
		BYTE		weReserved1;
		BYTE		weChksum;
		BYTE		wePart2[12];
		WORD       	weReserved2;
		BYTE		wePart3[4];
};
typedef struct winentry winentry;

struct winentryBytes 
{
		BYTE			weCnt;			// 
#define WIN_LAST        0x40
#define WIN_CNT         0x3f
		BYTE		wePart1[10];
		BYTE		weAttributes;
#define ATTR_WIN95      0x0f
		BYTE		weReserved1;
		BYTE		weChksum;
		BYTE		wePart2[12];
		BYTE       	weReserved2[2];
		BYTE		wePart3[4];
};
typedef struct winentryBytes winentryBytes;

#define WIN_ENTRY_CHARS	13      // Number of chars per winentry

// Maximum filename length in Win95
// Note: Must be < sizeof(dirent.d_name)
#define WIN_MAXLEN      255

// This is the format of the contents of the deTime field in the direntry
// structure.
// We don't use bitfields because we don't know how compilers for
// arbitrary machines will lay them out.
#define DT_2SECONDS_MASK        0x1F    // seconds divided by 2
#define DT_2SECONDS_SHIFT       0
#define DT_MINUTES_MASK         0x7E0   // minutes
#define DT_MINUTES_SHIFT        5
#define DT_HOURS_MASK           0xF800  // hours
#define DT_HOURS_SHIFT          11

// This is the format of the contents of the deDate field in the direntry
// structure.
#define DD_DAY_MASK				0x1F	// day of month
#define DD_DAY_SHIFT			0
#define DD_MONTH_MASK			0x1E0	// month
#define DD_MONTH_SHIFT			5
#define DD_YEAR_MASK			0xFE00	// year - 1980
#define DD_YEAR_SHIFT			9



// Stuctures
struct FileInfoStruct
{
	DWORD StartCluster;			//< file starting cluster for last file accessed
	DWORD Size;					//< file size for last file accessed
	BYTE Attr;					//< file attr for last file accessed
	//unsigned short CreateTime;			//< file creation time for last file accessed
	//unsigned short CreateDate;			//< file creation date for last file accessed
	DWORD Sector;				//<file record place
	WORD Offset;				//<file record offset
};
typedef struct FileInfoStruct FileInfoStruct;



extern WORD fatGetWord(BYTE * addr);
extern DWORD fatGetDWord(BYTE * addr);

#if FIX_DIRECTORY
	extern BYTE Search(BYTE *dir,struct direntryBytes*MusicInfo,WORD *Count,BYTE *type);//���������ļ�
	extern BYTE SearchLrc(BYTE *dir,BYTE * longnamebuffer,struct direntryBytes*LrcInfo);//serch lrc file
#else
	extern BYTE SearchInit(void);
	extern BYTE Search(WORD *music_record_addr,struct direntryBytes*MusicInfo,WORD *Count,BYTE *type);//���������ļ�
	extern BYTE SearchLrc(BYTE *dir,BYTE * longnamebuffer,struct direntryBytes*LrcInfo,WORD music_record_addr);//serch lrc file
#endif

extern BYTE FAT_LoadPartCluster(DWORD cluster,BYTE part,BYTE * buffer);//




extern BYTE FAT_Init(void);//
extern DWORD FAT_NextCluster(DWORD cluster);//
extern DWORD FAT_FindFreeCluster(void);//
extern BYTE FAT_DisDir(BYTE *dir);//
extern WORD FAT_FindItem(DWORD cluster, BYTE *name, struct FileInfoStruct *FileInfo);//
extern DWORD FAT_Open(BYTE * dir);//
extern DWORD FAT_OpenDir(BYTE * dir);//
extern BYTE FAT_Read(DWORD pointer, DWORD size);//
extern BYTE FAT_Rename(BYTE *dir,BYTE *newname);//
extern BYTE FAT_ModifyFAT(DWORD cluster,DWORD val);//
extern BYTE FAT_Delete(BYTE *dir);//
extern BYTE FAT_DelItem(struct FileInfoStruct *FileInfo);//
extern WORD FAT_FindFreeItem(DWORD cluster, struct FileInfoStruct *FileInfo);//
extern BYTE FAT_MkDir(BYTE * dir);//
extern BYTE FAT_Write(DWORD cluster,BYTE *data,DWORD size);//
extern DWORD FAT_Create(BYTE * dir,DWORD size);//
extern BYTE FAT_RmDir(BYTE * dir);//
extern WORD FAT_Close(DWORD * p);//
#endif




