/*----------------------------------------------------------------------------
 *      RL-ARM - TCPnet
 *----------------------------------------------------------------------------
 *      Name:    HTTP_DEMO.C
 *      Purpose: HTTP Server demo example
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2009 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include <stdio.h>
#include <RTL.h>
#include <Net_Config.h>
#include <stm32f10x_cl.h>
#include "GLCD.h"
#include <string.h>

BOOL LEDrun;
BOOL LCDupdate;
BOOL tick;
U32  dhcp_tout;
U8   lcd_text[2][16+1] = {" ",                /* Buffer for LCD text         */
                          "Waiting for DHCP"};

extern LOCALM localm[];                       /* Local Machine Settings      */
#define MY_IP localm[NETIF_ETH].IpAdr
#define DHCP_TOUT   50                        /* DHCP timeout 5 seconds      */

static void init_io (void);
static void init_display (void);

/*--------------------------- init ------------------------------------------*/

static void init () {
  /* Add System initialisation code here */ 

  init_io ();
  init_display ();
  init_TcpNet ();

  /* Setup and enable the SysTick timer for 100ms. */
  SysTick->LOAD = (SystemFrequency / 10) - 1;
  SysTick->CTRL = 0x05;
}

/*--------------------------- timer_poll ------------------------------------*/

static void timer_poll () {
  /* System tick timer running in poll mode */

  if (SysTick->CTRL & 0x10000) {
    /* Timer tick every 100 ms */
    timer_tick ();
    tick = __TRUE;
  }
}

/*--------------------------- init_io ---------------------------------------*/

static void init_io () {

  /* Set the clocks. */
  SystemInit();
  RCC->APB2ENR |= 0x00000279;

  /* Configure the GPIO for Push Buttons */
//  GPIOB->CRH &= 0xFFFFFF0F;
//  GPIOB->CRH |= 0x00000040;
//  GPIOC->CRH &= 0xFFF0FFFF;
//  GPIOC->CRH |= 0x00040000;

  /* Configure the PB1 for LEDs. */
  GPIOB->CRL &= 0xFFFFFF0F;  // Port PB1
  GPIOB->CRL |= 0x00000020;  // Output push pull
  


#ifdef USE_USART2
  /* Configure UART2 for 115200 baud. */
  AFIO->MAPR |= 0x00000008;
  GPIOD->CRL &= 0xF00FFFFF;
  GPIOD->CRL |= 0x04B00000;

  RCC->APB1ENR |= 0x00020000;
  USART2->BRR = 0x0135;
  USART2->CR3 = 0x0000;
  USART2->CR2 = 0x0000;
  USART2->CR1 = 0x200C;

#else
  /* Configure UART1 for 115200 baud. */

  RCC->APB2ENR |=   0x00000004;      // enable clock for GPIOA
  GPIOA->CRH   &= ~(0xFFUL  << 4);   // Clear PA9, PA10
  GPIOA->CRH   |=  (0x0BUL  << 4);   // USART1 Tx (PA9)  alternate output push-pull
  GPIOA->CRH   |=  (0x04UL  << 8);   // USART1 Rx (PA10) input floating

  RCC->APB2ENR |=   0x00004000;      // enable clock for USART1       

  USART1->BRR   =   0x28C;           // set baudrate 
  USART1->CR1   =   0x00000000;      // set Data bits
  USART1->CR2   =   0x00000000;      // set Stop bits
  USART1->CR1  |=   0x00000000;      // set Parity
  USART1->CR3   =   0x00000000;      // Set Flow Control

  USART1->CR1  |=   0x0000000C;      // RX, TX enable
  USART1->CR1  |=   0x00002000;      // USART enable

#endif  
  
  /* Configure ADC.14 input. */
  GPIOC->CRL &= 0xFFF0FFFF;
  ADC1->SQR1  = 0x00000000;
  ADC1->SMPR1 = (5<<12);
  ADC1->SQR3  = (14<<0);
  ADC1->CR1   = 0x00000100;
  ADC1->CR2   = 0x000E0003;

  /* Reset calibration */
  ADC1->CR2  |= 0x00000008;
  while (ADC1->CR2 & 0x00000008);

  /* Start calibration */
  ADC1->CR2  |= 0x00000004;
  while (ADC1->CR2 & 0x00000004);
  ADC1->CR2  |= 0x00500000;
}


/*--------------------------- fputc -----------------------------------------*/

int fputc (int ch, FILE *f)  {
  /* Debug output to serial port. */

#ifdef USE_USART2

  if (ch == '\n')  {
    while (!(USART2->SR & 0x0080));
    USART2->DR = 0x0D;
  }
  while (!(USART2->SR & 0x0080));
  USART2->DR = (ch & 0xFF);
  return (ch);

#else

  if (ch == '\n')  {
    while (!(USART1->SR & 0x0080));
    USART1->DR = 0x0D;
  }
  while (!(USART1->SR & 0x0080));
  USART1->DR = (ch & 0xFF);
  return (ch);

#endif
  
}


/*--------------------------- LED_out ---------------------------------------*/

void LED_out (U32 val) {
  U32 rv;

  rv = 0;
  if (val & 0x01) rv |= 0x00004000;
  GPIOE->BSRR = rv;
  GPIOE->BRR  = rv ^ 0x00004000;

  rv = 0;
  if (val & 0x02) rv |= 0x00002000;
  if (val & 0x04) rv |= 0x00000008;
  if (val & 0x08) rv |= 0x00000010;
  GPIOD->BSRR = rv;
  GPIOD->BRR  = rv ^ 0x0002018;
}


/*--------------------------- AD_in -----------------------------------------*/

U16 AD_in (U32 ch) {
  /* Read ARM Analog Input */
  U32 val = 0;

  if (ch < 1) {
    val = ADC1->DR & 0x0FFF;
  }
  return (val);
}


/*--------------------------- get_button ------------------------------------*/

U8 get_button (void) {
  /* Read ARM Digital Input */
  U32 val = 0;

  if ((GPIOB->IDR & (1 << 9)) == 0) {
    /* Key button */
    val |= 0x01;
  }
  if ((GPIOC->IDR & (1 << 13)) == 0) {
    /* Wakeup button */
    val |= 0x02;
  }
  return (val);
}


/*--------------------------- upd_display -----------------------------------*/

static void upd_display () {
  /* Update LCD Module display text. */

  GLCD_clearLn (Line5);
  GLCD_displayStringLn(Line5, lcd_text[0]);
  GLCD_clearLn (Line6);
  GLCD_displayStringLn(Line6, lcd_text[1]);

  LCDupdate =__FALSE;
}


/*--------------------------- init_display ----------------------------------*/

static void init_display () {
  /* LCD Module init */
#if 0
  GLCD_init();
  GLCD_clear(White);
  GLCD_setTextColor(Blue);
  GLCD_displayStringLn(Line1, "       RL-ARM");
  GLCD_displayStringLn(Line2, "    HTTP example");

  upd_display ();
#endif  
}


/*--------------------------- dhcp_check ------------------------------------*/

static void dhcp_check () {
  /* Monitor DHCP IP address assignment. */

  if (tick == __FALSE || dhcp_tout == 0) {
    return;
  }

  if (mem_test (&MY_IP, 0, IP_ADRLEN) == __FALSE && !(dhcp_tout & 0x80000000)) {
    /* Success, DHCP has already got the IP address. */
    dhcp_tout = 0;

#if 0    
    sprintf((char *)lcd_text[0],"IP address:");
    sprintf((char *)lcd_text[1],"%d.%d.%d.%d", MY_IP[0], MY_IP[1],
                                               MY_IP[2], MY_IP[3]);
#else
    printf("IP address:");
    printf("%d.%d.%d.%d\r\n", MY_IP[0], MY_IP[1],
                                               MY_IP[2], MY_IP[3]);
#endif
                                               
    LCDupdate = __TRUE;
    return;
  }
  if (--dhcp_tout == 0) {
    /* A timeout, disable DHCP and use static IP address. */
    dhcp_disable ();

#if 0    
    sprintf((char *)lcd_text[1]," DHCP failed    " );
#else
    printf("DHCP failed\r\n" );
#endif

    LCDupdate = __TRUE;
    dhcp_tout = 30 | 0x80000000;
    return;
  }
  if (dhcp_tout == 0x80000000) {
    dhcp_tout = 0;

#if 0    
    sprintf((char *)lcd_text[0],"IP address:");
    sprintf((char *)lcd_text[1],"%d.%d.%d.%d", MY_IP[0], MY_IP[1],
                                               MY_IP[2], MY_IP[3]);
#else
    printf("IP address:");
    printf("%d.%d.%d.%d\r\n", MY_IP[0], MY_IP[1],
                                               MY_IP[2], MY_IP[3]);
#endif
                                              
    LCDupdate = __TRUE;
  }
}


/*--------------------------- blink_led -------------------------------------*/

static void blink_led () {

#if 0
  /* Blink the LEDs on an eval board */
  const U8 led_val[8] = { 0x01,0x03,0x07,0x0F,0x0E,0x0C,0x08,0x00 };
  static U32 cnt;

  if (tick == __TRUE) {
    /* Every 100 ms */
    tick = __FALSE;
    if (LEDrun == __TRUE) {
      LED_out (led_val[cnt]);
      if (++cnt >= sizeof(led_val)) {
        cnt = 0;
      }
    }
    if (LCDupdate == __TRUE) {
      upd_display ();
    }
  }
#endif
  
}

/*---------------------------------------------------------------------------*/

int main (void) {
  /* Main Thread of the TcpNet */

  init ();
  //LEDrun = __TRUE;
  //dhcp_tout = DHCP_TOUT;
    
  dhcp_disable();
  
  while (1) {
    timer_poll ();
    main_TcpNet ();
    // dhcp_check ();
    //blink_led ();
  }
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/
