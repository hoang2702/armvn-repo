#ifndef	__SDMMC_H
#define	__SDMMC_H


#define 	CMD_TIMOUT 		8000
#define 	ACCESS_TIMEOUT 	0x6ffff

// Select MSD Card: ChipSelect pin low  
#define SPI_CS_Assert     GPIO_ResetBits(GPIOC, GPIO_Pin_12)
// Deselect MSD Card: ChipSelect pin high //
#define SPI_CS_Deassert    GPIO_SetBits(GPIOC, GPIO_Pin_12)


#define IS_SPI_I2S_GET_FLAG(FLAG) (((FLAG) == SPI_I2S_FLAG_BSY) || ((FLAG) == SPI_I2S_FLAG_OVR) || \
                                   ((FLAG) == SPI_FLAG_MODF) || ((FLAG) == SPI_FLAG_CRCERR) || \
                                   ((FLAG) == I2S_FLAG_UDR) || ((FLAG) == I2S_FLAG_CHSIDE) || \
                                   ((FLAG) == SPI_I2S_FLAG_TXE) || ((FLAG) == SPI_I2S_FLAG_RXNE))

extern void   spi_init (void);
extern uint8  MMC_SD_Init(void);
extern uint8  MMC_SD_ReadSingleBlock(uint32 sector, uint8* buffer);
extern uint8  MMC_SD_WriteSingleBlock(uint32 sector, uint8* buffer);
extern uint32 MMC_SD_ReadCapacity(void);
#endif
