===========REV 1.01=========
Added folder to support new ST CMISS LIB 3.10

Fully working with Circle_OS 3.8.

Still less ressources to play 320kbit smoothly.

===========REV 1.01=========
This is an application for STM32 Primer 2, which enables the playback of MP3 files. The decoder is based on Helix MP3 Library. The library has an integer decoder there is suitable for smaller microcontrollers.
The implementation makes it possible to listen to most common variants of MP3. 320kbit files can have small problems due to speed of the microcontroller.
The system also can read ID3V1 out of the file and show it as flying text on the screen.
There has been added touch icons to control the player.
This application is build based on the Play Wave application which Francis from Raisonance and I am the author off, my role was mainly to update the circleOS to play audio from DMA and improve the sound quality.


Note: The Helix library has been ported to thumb-2 code and has been changed to static memory configuration for this project.
https://datatype.helixcommunity.org/Mp3dec

