void init_serial (void);
void test (void);
