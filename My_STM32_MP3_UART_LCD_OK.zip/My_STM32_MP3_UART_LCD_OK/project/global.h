#ifndef 	global_h_
#define 	global_h_

#include   	<string.h>	
#include   	<stdio.h>  
#include    <ctype.h>
#include    <stdlib.h>
#include    <setjmp.h>
#include    <rt_misc.h>

#define Fosc             12000000                    //Crystal frequence,10MHz~25MHz��should be the same as actual status. 
#define Fcclk           (Fosc * 4)                  //System frequence,should be (1~32)multiples of Fosc,and should be equal or less  than 60MHz. 
#define Fcco            (Fcclk * 4)                 //CCO frequence,should be 2��4��8��16 multiples of Fcclk, ranged from 156MHz to 320MHz. 
#define Fpclk           (Fcclk / 4) * 1             //VPB clock frequence , must be 1��2��4 multiples of (Fcclk / 4).


#define CHAR		char
#define BYTE		unsigned char
#define WORD		unsigned short
#define DWORD		unsigned int
#define uint8		unsigned char
#define int8		signed char
#define uint16		unsigned short
#define int16		signed short
#define uint32		unsigned int
#define int32		signed int

#define printf_P printf
#define iprintf  printf



extern WORD get16(BYTE * addr);
extern WORD get16_big(BYTE * addr);
extern WORD get16_little(BYTE * addr);
extern DWORD get32(BYTE * addr);
extern DWORD get32_big(BYTE * addr);

extern DWORD get32_little(BYTE * addr);
extern void put16(BYTE * addr, WORD val);
extern void put16_big(BYTE * addr, WORD val);
extern void put16_little(BYTE * addr, WORD val);
extern void put32(BYTE * addr, DWORD val);
extern void put32_big(BYTE * addr, DWORD val);
extern void put32_little(BYTE * addr, DWORD val);
extern WORD swap16(WORD val);
extern DWORD swap32(DWORD val);
void dump_memory(unsigned char * addr, unsigned int length);
void soft_delay_ms(uint32 t);


#endif
