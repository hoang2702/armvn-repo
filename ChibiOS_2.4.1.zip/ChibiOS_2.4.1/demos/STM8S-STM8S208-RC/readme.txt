*****************************************************************************
** ChibiOS/RT demo for STM8S208RB.                                         **
*****************************************************************************

** TARGET **

The demo runs on a Raisonance REva+STM8S208RB board.

** The Demo **

The demo flashes the board LED using a thread, by pressing the button located
on the board the test procedure is activated with output on the serial port.

** Build Procedure **

From withing the Ride7 IDE open the project, compile and run it.
