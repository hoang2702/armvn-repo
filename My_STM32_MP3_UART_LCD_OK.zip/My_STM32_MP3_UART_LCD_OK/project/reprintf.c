/*
  * @file    reprintf.c 
*/ 

/* standard include */
#include <stdio.h>
/* application include */
#include "reprintf.h"
#include "lcd.h"
#include "stm32f10x_usart.h"

extern enum DEV_TYPE globalDev = DEV_LCD;		/* Default Value*/
extern void setTargetDev(enum DEV_TYPE dev)
{
    globalDev = dev;
}

PUTCHAR_PROTOTYPE
{
	switch(globalDev)
    {
        case DEV_LCD:
			/* Place your implementation of fputc here */
  			/* e.g. write a character to the LCD */
            lcd_Data_Write((u8) ch);
			//return ch;
            break;

        case DEV_USART1:
            /* Place your implementation of fputc here */
            /* e.g. write a character to the USART1 */
            USART_SendData(USART1, (u8) ch);
            /* Loop until the end of transmission */
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET)
            {}
		//	return ch;
            break;
    }   
    return ch;
}


