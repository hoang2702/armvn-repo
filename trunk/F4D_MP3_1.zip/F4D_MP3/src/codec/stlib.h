#pragma once
#include "st_stm32f4xx.h"
#include "st_stm32f4xx_dma.h"
#include "st_stm32f4xx_i2c.h"
#include "st_stm32f4xx_gpio.h"
#include "st_stm32f4xx_rcc.h"
#include "st_stm32f4xx_spi.h"

#define assert_param(expr) ((void)0)
