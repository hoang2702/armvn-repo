#include 	"stm32f10x_lib.h"
#include 	"platform_config.h"

#ifndef	__VS1003_C
#define	__VS1003_C
#include 	"stdio.h"
#include 	"vs1003.h"
#include 	"uart.h"

//---------------------------------------------------------------------------//
void _delay_ms(uint8 y)
{
	for(;y>0;y--);
}
//---------------------------------------------------------------------------//
unsigned char VS1003B_NeedData (void)
{
	if (GPIO_ReadInputDataBit (VS1003B_DREQ_PORT, VS1003B_DREQ) != 0)
		return 1;
	return 0;
}
//---------------------------------------------------------------------------//
void dreq_request (void)
{
	//while (!(GPIO_ReadInputDataBit (VS1003B_DREQ_PORT, VS1003B_DREQ)));
	while ((GPIOB->IDR & VS1003B_DREQ)==0);
}
//----------------------------------------------------------------------------//
unsigned char VS1003B_WriteByte(unsigned char dat)
{  
	unsigned char  i;
	for (i = 0; i < 8; i++)
	{
		if (dat & 0x80)
			GPIO_SetBits (GPIOB,VS1003B_MOSI);
		else 
			GPIO_ResetBits (GPIOB,VS1003B_MOSI);
		VS1003B_SCK_H();
		VS1003B_SCK_L();
		dat = dat << 1;
	}
	return dat;  //no effect
}
//----------------------------------------------------------------------------//
/* read one byte from vs1003 */
unsigned char VS1003B_ReadByte()
{
	unsigned char dat=0,i;

	for (i = 0; i < 8; i++)
	{
	//	if (IOPIN0 & (VS1003B_MISO))
		if ((GPIOB->IDR & VS1003B_MISO))
			dat |= 0x01;
		dat = dat << 1;
		
		VS1003B_SCK_H();
		VS1003B_SCK_L();
	}
	return dat;  //retrun value
}
//----------------------------------------------------------------------------//
//  config register 
void VS1003B_WriteCMD(unsigned char addr, unsigned short dat)
{
	VS1003B_XDCS_H();
	VS1003B_XCS_L();
	VS1003B_WriteByte(0x02);
	VS1003B_WriteByte(addr);
	VS1003B_WriteByte(dat>>8);
	VS1003B_WriteByte(dat);
	VS1003B_XCS_H();
}
//----------------------------------------------------------------------------//
unsigned short VS1003B_ReadCMD(unsigned char addr)
{
	unsigned short temp;
	VS1003B_XDCS_H();
	VS1003B_XCS_L();
	VS1003B_WriteByte(0x03);
	VS1003B_WriteByte(addr);
	temp = VS1003B_ReadByte();
	temp <<= 8;
	temp += VS1003B_ReadByte();
	VS1003B_XCS_H();
	return temp;
}
//----------------------------------------------------------------------------//
/* Write 32bytes data */
void VS1003B_Write32B(unsigned char * buf)
{
	unsigned char n = 32;
	VS1003B_XDCS_L();
	while(n--)
	{
		VS1003B_WriteByte(*buf++);
	}
	VS1003B_XDCS_H();
}
//----------------------------------------------------------------------------//
/* get total decode time form last reset */
unsigned short VS1003B_ReadDecodeTime()
{
	return VS1003B_ReadCMD(0x04);
}
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//




/* Set volume */
void VS1003B_SetVolume(unsigned short vol)
{
	VS1003B_WriteCMD(0x0b,vol);	
}

/*
//moi lam
void VS1003B_SetVolume(unsigned int vol)   
{   
    VS1003B_SPI_High();   
    VS1003B_WriteCMD(0x0b,vol);    
}  */






//---------------------------------------------------------------------------//
void VS1003B_SetBass (unsigned short bass)
{
	VS1003B_WriteCMD(0x02,bass);	
}
//---------------------------------------------------------------------------//
void VS1003B_Fillclear (void)
{
	unsigned char  i,j;

	for(i=0;i<64;i++)
	{
		VS1003B_XDCS_L();
		dreq_request ();
		for(j=0;j<32;j++)
		{
			VS1003B_WriteByte(0x00);
		}
		VS1003B_XDCS_H();
	}
}
//---------------------------------------------------------------------------//
void VS1003B_SoftReset (void)
{
	dreq_request ();
	VS1003B_WriteCMD (VS_MODE,0x0804); 			// Active Software Reset + SPI New Mode	 

	_delay_ms(5);						// 100mS Delay

	dreq_request ();
	VS1003B_WriteCMD (VS_CLOCKF,XTAL_12288); 	// VS1002 Clock = 12.288 MHz + Double Clock

	dreq_request ();
	VS1003B_WriteCMD (VS_AUDATA,48000);  		// Set Sampling Rate 8KHz

	dreq_request ();
	VS1003B_Fillclear ();		  			// Reset All Memory (2048 byte)	

	dreq_request ();
	VS1003B_SetVolume (0x0000);				// Set Volume = Maximum

	/*VS1003B_WriteCMD(Mode, value) 
 VS1003B_SetVolume (0x0000-0xFFFF);  MAX =0x0000
 VS1003B_SetBass (0x0000-0xFFFF); MAX =0x0000*/
	
	dreq_request ();
	VS1003B_SetBass (0x8080);				//Set bass
}
//----------------------------------------------------------------------------//
unsigned char VS1003B_Init(void)
{
   GPIO_InitTypeDef  GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin   = VS1003B_XCS | VS1003B_XDCS | VS1003B_XRESET |VS1003B_SCK | VS1003B_MOSI;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

 /*	GPIO_InitStructure.GPIO_Pin = VS1003B_DREQ | VS1003B_MISO | NEXT;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

 	VS1003B_XRESET_L();
	_delay_ms(30);
	VS1003B_XRESET_H();
	VS1003B_SoftReset ();
	
	return 0;
}
#endif
