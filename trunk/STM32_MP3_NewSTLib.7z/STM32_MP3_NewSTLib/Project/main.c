/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"


#include "platform_config.h"
#include "stdio.h"
#include "uart.h"
#include "sdmmc.h"
#include "fat.h"

GPIO_InitTypeDef GPIO_InitStructure;
ErrorStatus HSEStartUpStatus;


// Private functions ---------------------------------------------------------//
// Function Name  : RCC_Configuration
//Description    : Configures the different system clocks.
//
void RCC_Configuration(void)
{   
  /* RCC system reset(for debug purpose) */
  RCC_DeInit();
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);
  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if(HSEStartUpStatus == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);
    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1); 
    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1); 
    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);
    /* PLLCLK = 8MHz * 9 = 72 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
     /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);
     /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }
    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}
//-----------------------------------------------------------------------------//
//Function Name  : NVIC_Configuration
//Description    : Configures Vector Table base location.
// Input          : None
void NVIC_Configuration(void)
{
#ifdef  VECT_TAB_RAM  
  /* Set the Vector Table base location at 0x20000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
#endif
}
//------------------------------------------------------------------------------//
extern unsigned char LongNameBuffer[MAX_LONG_NAME_SIZE];
extern unsigned char LongNameFlag;
extern BYTE FAT32_Enable;
extern WORD SectorsPerClust;
extern WORD FirstDataSector;

#define LRC_PATH "\\lrc"

struct direntryBytes MusicInfo;	// Music file information, 32Bytes short directory record, contain the short name and others //
struct direntryBytes LrcInfo;	// lyric file information, 32Bytes short directory record, the short name and others //

uint16 		totalsongs;		// total number of songs//
uint8 		type;			// current song's file type
uint8 		lrc =0;			// Gloable variable to indicate wether the songs has a lyric file, 1 means have //
uint8 		dis;


struct LrcStruct_s {
struct LrcStruct_s * next;	
uint32 time;				
uint16 eeaddr;			
};
typedef struct LrcStruct_s LrcStruct_s;
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//#define DEBUG 0	// Macro for DEBUG, if 1 DEBUG message will show throw the UART //

//--------------------------------------------------------------------------------//

#define MAXITEM 120
uint8 lrcbuffer[sizeof(struct LrcStruct_s) * MAXITEM];

// Use to record the lyric data //
#define MAXLRCDATSIZE 4096			// Max data size in SRAM, other will be store in EEPROM of ATmega64 //
uint8 lrcdatbuf[MAXLRCDATSIZE];
uint8 track[128];			// stroe the information of songs (bit set indicate songs has been played) //
//--------------------------------------------------------------------------------//
void ClearTrackInfo()		// cleare the array track[128] //
{
	uint8 i;
	for(i=0;i<128;i++)track[i] = 0;
}
//--------------------------------------------------------------------------------//
void Delay(uint16 n)
{
	while(n--);
}
//------------------------------------------------------------------------------//
//------------------------------------------------------------------------------//
//------------------------------------------------------------------------------//
//---------------------------------------------------------------------------------//
void print_name (uint8 *filename)
{
	uint8 i;
	for (i=0;;i++)
	{
		if ((i >= MAX_LONG_NAME_SIZE) || (filename[i] == '.'))
			break;
		printf ("%c",filename[i]);
	}
}
//---------------------------------------------------------------------------------//
uint8 Search_mp3()
{
	uint16 count;			//data counting
	uint8 i;				//loop variable
	uint16 j;				//loop variable	
	DWORD p;				//cluster
	uint8 *buffer;			//buffer
	uint16 songs = 1;
#define MAX_LRC_DISP 52
	uint16 lrcaddr;
 	ClearTrackInfo();
	if (totalsongs == 0)
	{
		printf ("\r\nFile not found");
		return 0;
	}	

	count=0;//clear count
   	Search(&lrcaddr,&MusicInfo,&songs,&type);	
		for(j=0;j<MAX_LONG_NAME_SIZE/2;j++)// cut off the extension, only leave the name
		{
			if(((uint8 *)LongNameBuffer)[j] == 0)
			{
				((uint8 *)LongNameBuffer)[j-4] = 0;
				break;
			}
		}
		if(!LongNameFlag)//BYTE LongNameFlag = 0;
		{
			for(j=0;j<8;j++)
			{
				if(MusicInfo.deName[j]==0x20) break;
				LongNameBuffer[j]=MusicInfo.deName[j];
			}
			LongNameBuffer[j++]='\0';
			LongNameBuffer[j++]='.';
			count = j+3;
			for(count=0;count<3;count++)
				LongNameBuffer[j+count]=MusicInfo.deExtension[count];
			LongNameBuffer[j+count]='\0';
		}
		print_name(LongNameBuffer);
	p     = get16_little(MusicInfo.deStartCluster)+(((uint32)get16_little(MusicInfo.deHighClust))<<16);	//the first cluster of the file
		
		i=0;
  while(1)
	{
			
//XXXXXXXXXXXXXXXXXXXXXX		
	   	for(;i<SectorsPerClust;i++)
			{
				buffer=malloc(512);
				FAT_LoadPartCluster(p,i,buffer);//read a sector												
				count=0;
			}
 };
}
//------------------------------------------------------------------------------//

int main(void)
{
  	// System Clocks Configuration 
  	RCC_Configuration();   
  	// NVIC Configuration 
  	NVIC_Configuration();

  init_serial();   // Enable USART1                             
	spi_init ();	/* SPI1 enable */	
	
	printf ("\r\nInit SD/MMC");
	while(MMC_SD_Init());//SD Card_Configuration 
	printf(("\r\nSD initialize OK!"));

	FAT_ReadSector   = MMC_SD_ReadSingleBlock;//device read
	FAT_WriteSector  = MMC_SD_WriteSingleBlock;//device write
	FAT_ReadCapacity = MMC_SD_ReadCapacity;//read capacity
	printf(("\r\nDisk size is: %ld MB"),FAT_ReadCapacity()/1024/2);
	
	if(FAT_Init())
	{							 
		printf(("\r\nFAT initialize fialed! Or System error!"));
		printf(("\r\nYou may try to turn off the power and then power on."));
		printf(("\r\nOtherwise pls check that whether your card is correctly fomated"));
		while(1);
	}
	else 
	{
		printf(("\r\nFAT initialize OK!"));
	}
	dis = 1;
	SearchInit();
	Search(0,&MusicInfo,&totalsongs,&type);
	printf ("\r\n\nFound %d songs\r\n",totalsongs);
	dis = 0;
 	while (1); 
}

//===========================================

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: _PRINTF("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
//------------------------------------------------------------------------------//

