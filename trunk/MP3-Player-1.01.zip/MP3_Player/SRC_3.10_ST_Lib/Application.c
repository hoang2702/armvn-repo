/************************* (C) COPYRIGHT 2007 RAISONANCE **********************
* File Name          :  Application.c
* Author             :  Francis/Raisonance + Kasper.
* Date First Issued  :  28-06-2009
* Description        :  Wave+MP3 Player
*                       Sources:  
*                          1. The wave parser has been copied from the STM examples 
*                          (eval board for the STM32F103E).
*                          2. The management of the sound buffer has been written by 
*                          Kasper Repzak.
*                          3. Added MP3 Library from Helix www.helixcommunity.org
*                          Supports most common MP3 formats / Ported to Primer2 by Kasper
*                          (Asm code ported to thumb2 code)
*                          (Can have some speed issues with 320kbit
*                          4. Added touch button to application (Start / Stop / Open / Quit)
*                          5. Added Flying text for writing long strings
*                          6. Added ID3V1 Support to read data about MP3 FIle
*                       
*   Known Issues working together with CircleOS 3.71:
*   - Circle OS Version 3.71 must be fixed with audio fix for MP3-Mono to work.
*   - There are issues with the SD_Read function, sometimes it locks up in Read, there is a While loop without timeout..                       
*   - Have seen Problems with different version of CircleOS 3.71, The sourcecode posted in projects seems not to work
*     But the ELF file included in the upgrade file in the reaource file is working correctly.
* 
*   Work-Arrounds:
*   - Changing interupt priority group in initlization, due to differen priority group the first run of application compared to second run
*   - When reading from SD-card, the read buffer must be Word alligned for not missing data
* Revision           :  1.0
*******************************************************************************/
/* .WAV file format :

 Endian      Offset      Length      Contents
  big         0           4 bytes     'RIFF'             // 0x52494646
  little      4           4 bytes     <file length - 8>
  big         8           4 bytes     'WAVE'             // 0x57415645

Next, the fmt chunk describes the sample format:

  big         12          4 bytes     'fmt '          // 0x666D7420
  little      16          4 bytes     0x00000010      // Length of the fmt data (16 bytes)
  little      20          2 bytes     0x0001          // Format tag: 1 = PCM
  little      22          2 bytes     <channels>      // Channels: 1 = mono, 2 = stereo
  little      24          4 bytes     <sample rate>   // Samples per second: e.g., 22050
  little      28          4 bytes     <bytes/second>  // sample rate * block align
  little      32          2 bytes     <block align>   // channels * bits/sample / 8
  little      34          2 bytes     <bits/sample>   // 8 or 16

Finally, the data chunk contains the sample data:

  big         36          4 bytes     'data'        // 0x64617461
  little      40          4 bytes     <length of the data block>
  little      44          *           <sample data>

*/


/* Includes ------------------------------------------------------------------*/

//#include "stm32f10x_lib.h"
#include "stm32f10x.h"
#include "Display_control.h"
#include "circle_api.h"
#include <string.h>
#include "mp3dec.h"
#include "mp3common.h"



/* Private typedef -----------------------------------------------------------*/

/* Audio file information structure */
typedef enum
    {
    LittleEndian,
    BigEndian
    } Endianness;

typedef struct
    {
    u32  RIFFchunksize;
    u16  FormatTag;
    u16  NumChannels;
    u32  SampleRate;
    u32  ByteRate;
    u16  BlockAlign;
    u16  BitsPerSample;
    u32  DataSize;
    } WAVE_FormatTypeDef;

/* Error Identification structure */
typedef enum
    {
    Valid_WAVE_File = 0,
    Invalid_RIFF_ID,
    Invalid_WAVE_Format,
    Invalid_FormatChunk_ID,
    Unsupporetd_FormatTag,
    Unsupporetd_Number_Of_Channel,
    Unsupporetd_Sample_Rate,
    Unsupporetd_Bits_Per_Sample,
    Invalid_DataChunk_ID,
    Unsupporetd_ExtraFormatBytes,
    Invalid_FactChunk_ID
    } ErrorCode;

typedef enum {
    StateExploring,
    StateRun,
    StateIdle
    } PLAYER_State;


/* Private macro -------------------------------------------------------------*/
#define HEADER_SIZE          44
#define NEEDEDVERSION "V 3.71" // Put here the minimal CircleOS version needed by your application

#define  ChunkID             0x52494646  /* correspond to the letters 'RIFF' */
#define  FileFormat          0x57415645  /* correspond to the letters 'WAVE' */
#define  FormatID            0x666D7420  /* correspond to the letters 'fmt ' */
#define  DataID              0x64617461  /* correspond to the letters 'data' */
#define  FactID              0x66616374  /* correspond to the letters 'fact' */

#define  WAVE_FORMAT_PCM     0x01
#define  FormatChunkSize     0x10
#define  Channel_MONO        0x01
#define  Channel_STEREO      0x02

#define  SampleRate_8000     8000
#define  SampleRate_16000    16000
#define  SampleRate_22050    22050
#define  SampleRate_44100    44100
#define  SampleRate_48000    48000
#define  Bits_Per_Sample_8   8
#define  Bits_Per_Sample_16  16

/* Private variables ---------------------------------------------------------*/
u8 fEOF = 0; //FlagEndOfFile
u8 HeaderTabIndex = 0;
u8 AudioFileHeader[HEADER_SIZE]; 
AUDIO_Length_enum i2saudiolength;
AUDIO_PlaybackBuffer_Status BufferStatus; // Status of buffer
u32 DataStartAddr = 0x0;
u32 Real_wav_samplerate;        // Copy of the samplerate in real number, not Enum..
PLAYER_State State;             // State of playback
WAVE_FormatTypeDef  WAVE_Format;
volatile ErrorCode  WaveFileStatus = Invalid_RIFF_ID;   
s16 AudioBuffer[4608];          // Playback buffer - Value must be 4608 to hold 2xMp3decoded frames.
FILEINFO file_info;             // File info
u32 StartMBR;                   // Start MBR
VOLINFO volume_info;            // Volume Info


// MP3
#define READBUF_SIZE 4000       // Value must min be 2xMAINBUF_SIZE = 2x1940 = 3880bytes
MP3FrameInfo mp3FrameInfo;      // Content is the output from MP3GetLastFrameInfo, 
                                // we only read this once, and conclude it will be the same in all frames
                                // Maybe this needs to be changed, for different requirements.
static HMP3Decoder hMP3Decoder; // Content is the pointers to all buffers and information for the MP3 Library
u32 Old_Pll;                    // Saves the PLL setting before we change it to Very high speed in MP3 section
volatile u32 bytesLeft;         // Saves how many bytes left in readbuf
volatile u32 outOfData;         // Used to set when out of data to quit playback
u8 readBuf[READBUF_SIZE];       // Read buffer where data from SD card is read to
u8 *readPtr;                    // Pointer to the next new data
tHandler old_tim5_irq;          // Saves t he old timer for IRQ vector
// MP3 END



   
/* Private functions ---------------------------------------------------------*/
static enum MENU_code MsgVersion(void);
static u32 ReadUnit(u8 NbrOfBytes, Endianness BytesFormat);
void FillBuffer (u32 start);
static ErrorCode I2S_CODEC_WaveParsing(u8* HeaderTab);

/* Public variables ----------------------------------------------------------*/
const char Application_Name[8+1] = {"MP3 Play"};  // max 8 characters for application name
u8 CurrentPath[MAX_PATH_LENGTH];
extern u8 CurrentPath[MAX_PATH_LENGTH];

/*******************************************************************************
* Function Name  : TIM5_irq
* Description    : Calls Fillbuffer to periodic update and decode musik
*                  This has lower priority than systemhandler and TIM2 (MEMS)
* Input          : None
* Return         : None
*******************************************************************************/
void TIM5_irq(void)
{
    FillBuffer(0);
    /* Clear TIM5 update interrupt */
    TIM_ClearITPendingBit( TIM5, TIM_IT_Update );
}



/*******************************************************************************
* Function Name  : Application_Ini
* Description    : Initialization function of Circle_App. This function will
*                  be called only once by CircleOS.
* Input          : None
* Return         : MENU_CONTINUE_COMMAND
*******************************************************************************/
enum MENU_code Application_Ini ( void )
    { 
    NVIC_InitTypeDef NVIC_InitStructure; 
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    if( strcmp (UTIL_GetVersion(), NEEDEDVERSION) < 0)
        {
        return MsgVersion();
        }

    LED_Set (LED_RED   ,   LED_OFF);       // Turn Off LED to save power
    LED_Set (LED_GREEN   , LED_OFF);       // Turn Off LED to save power
    
    /* Saves the old pll value and set new */
    Old_Pll = UTIL_GetPll (); 
    UTIL_SetPll (SPEED_VERY_HIGH);
    MENU_SetAppliDivider(10);
    

    /* Saves the old TIM5 irw handler */
    old_tim5_irq = (tHandler)UTIL_GetIrqHandler  ( 264 );
    /* Sets the new TIM5 irw handler */
    UTIL_SetIrqHandler  ( 264, (tHandler)TIM5_irq);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1); // Workarround for priorityGroup is changed in FS.C
    
    /* Change the systemhandler priority to higher, so TIM5 can get a lower Priority */
    //NVIC_SystemHandlerPriorityConfig(SysTick_IRQn, 0, 7 ); // SystemHandler_SysTick
    NVIC_SetPriority( SysTick_IRQn, 7 );

    /* Enable TIM Clock */
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM5, ENABLE );  

    /* TIM5 configuration */
    TIM_TimeBaseStructure.TIM_Period          = 1;
    TIM_TimeBaseStructure.TIM_Prescaler       = 0x0;
    TIM_TimeBaseStructure.TIM_ClockDivision   = 0x0;
    TIM_TimeBaseStructure.TIM_CounterMode     = TIM_CounterMode_Up;
    TIM_TimeBaseInit( TIM5, &TIM_TimeBaseStructure );
    /* TIM5 enable counter */
    TIM_Cmd( TIM5, ENABLE );

    /* Clear TIM5 update pending flag */
    TIM_ClearFlag( TIM5, TIM_FLAG_Update );

    /* Enable the TIM5 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel                    = TIM5_IRQn;  // TIM5_IRQChannel;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority  = 1;  
    NVIC_InitStructure.NVIC_IRQChannelSubPriority         = 7; 
    NVIC_InitStructure.NVIC_IRQChannelCmd                 = ENABLE;
    NVIC_Init( &NVIC_InitStructure );
    
    /* Initilizes the MP3 Library */
    hMP3Decoder = MP3InitDecoder();
    
    /* Turns off Speaker */
    AUDIO_SPEAKER_OnOff(OFF);
    
    /* Explorer the SD card */
    State = StateExploring;
    return FS_Explorer_Ini ( );
    }


void OpenAudioFile(void)
     {
                DRAW_Clear();
                flying_text[0].curr_pos =0;
                flying_text[0].text_length =0;
                flying_text[0].x = 10;
                flying_text[0].y = 25;
                flying_text[0].disp_length = 15;  
                strcpy (flying_text[0].text ,CurrentPath);
                flying_text[0].text_length = strlen(CurrentPath);
                    
                // mount MMCSD 
                StartMBR=FS_Mount(MMCSD_SDIO);
                if (StartMBR == 0xFFFFFFFF)
                    {
                    DRAW_Puts("\n No SDCARD");
                    return -1;
                    }

                // Open volume on first partition (0)
                if (FS_GetVolumeInfo(0, StartMBR, &volume_info))
                    {
                    DRAW_Puts("\nErr: GetVolInfo");
                    return -1;
                    }

                //Open selected file
                if (FS_OpenFile(&volume_info, CurrentPath,FS_READ, &file_info))
                    {
                    DRAW_Puts("\n Err op: File");
                    return MENU_Quit();
                    }       
                  Draw_Display(&file_info);
                  fEOF = 0; 
                strupr(CurrentPath);
                }
            
void PlayAudioFile(void)
           {
           u8 err_ptr[6];
           if ( strstr(CurrentPath, "WAV") )
                    {
                    u32 i ; 
                    FS_ReadFile(&file_info, (u8 *)AudioFileHeader, &i, HEADER_SIZE);
                    if ( i == HEADER_SIZE )
                        {
                        ErrorCode ret = I2S_CODEC_WaveParsing( (u8*) AudioFileHeader);
                        if ( ret == Valid_WAVE_File )
                            {
                            AUDIO_SetMode  (
                                        AUDIO_CIRCULAR_MODE,
                                        (WAVE_Format.BitsPerSample==16) ? LG_16_BITS : LG_8_BITS,
                                        WAVE_Format.SampleRate,
                                        (WAVE_Format.NumChannels==1) ? MONO : STEREO );
                            
                         UTIL_int2str  ( err_ptr,    Real_wav_samplerate/1000,    2,    0 );  
                         DRAW_DisplayString (5, 5,err_ptr,3);
                        
                         if (WAVE_Format.NumChannels == 1)
                            DRAW_DisplayString (37, 5,"Ks/S - Mono",11);
                        else
                            DRAW_DisplayString (37, 5,"Ks/S - Stereo",13); 
                            
                            
                            FillBuffer(1);               
                            AUDIO_Play(AudioBuffer,sizeof(AudioBuffer) / ((WAVE_Format.BitsPerSample==16) ? 2:1) );
                            /* Enable TIM5 Update interrupt */
                            TIM_ITConfig( TIM5, TIM_IT_Update, ENABLE );
                            }
                        }                    
                    }
                else if ( strstr(CurrentPath, "REC") )
                    {
                    AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS, FRQ_16KHZ, MONO);
                    FillBuffer(1);               
                    AUDIO_Play(AudioBuffer,sizeof(AudioBuffer)/sizeof(s16));
                    /* Enable TIM5 Update interrupt */
                    TIM_ITConfig( TIM5, TIM_IT_Update, ENABLE );
                    }
                else if ( strstr(CurrentPath, "MP3") )
                    {                    
                    /* Reset counters */
                    bytesLeft = 0;
                    outOfData = 0;
                    readPtr = readBuf;
                    /* Read the first data to get info about the MP3 File */
                    FillBuffer(1); 
                    /* Get the length of the decoded data, so we can set correct play length */                        
                    MP3GetLastFrameInfo(hMP3Decoder, &mp3FrameInfo); // Maybe it must be read and settings set for every frame..??
  
                    /* Select the correct samplerate and Mono/Stereo */
                    switch(((MP3DecInfo *)hMP3Decoder)->samprate)
                        {
                        case 8000: AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS,FRQ_8KHZ,(((MP3DecInfo *)hMP3Decoder)->nChans==1) ? MONO : STEREO);
                            break;
                        case 16000: AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS,FRQ_16KHZ,(((MP3DecInfo *)hMP3Decoder)->nChans==1) ? MONO : STEREO);
                            break;
                        case 22050: AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS,FRQ_22KHZ,(((MP3DecInfo *)hMP3Decoder)->nChans==1) ? MONO : STEREO);
                            break;
                        case 44100: AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS,FRQ_44KHZ,(((MP3DecInfo *)hMP3Decoder)->nChans==1) ? MONO : STEREO);
                            break;
                        case 48000: AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS,FRQ_48KHZ,(((MP3DecInfo *)hMP3Decoder)->nChans==1) ? MONO : STEREO);
                            break;
                        }             
                                    /* If we like too se details for the file */
                                    #ifdef Show_Debug_info
                                    char err_ptr[9];
                                    DRAW_Puts("\nChannels: ");
                                    UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->nChans,    1,    1  );
                                    DRAW_Puts(err_ptr); 
                                    DRAW_Puts("\nSample Ra:");
                                    UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->samprate,    5,    1  );
                                    DRAW_Puts(err_ptr);            
                                    DRAW_Puts("\nNGrans: ");
                                    UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->nGrans,    4,    1  );
                                    DRAW_Puts(err_ptr);   
                                    DRAW_Puts("\nNGranSamp:");
                                    UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->nGranSamps,    4,    1 );
                                    DRAW_Puts(err_ptr);   
                                    DRAW_Puts("\nLayer: ");
                                    UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->layer,    4,    1  );
                                    DRAW_Puts(err_ptr);   
                                    DRAW_Puts("\nVersion: ");
                                    UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->version,    4,    1 );
                                    DRAW_Puts(err_ptr);  
                                    DRAW_Puts("\nBitrate: ");
                                    #endif  
                        
                     // Print the bitrate
                     UTIL_int2str  ( err_ptr,    ((MP3DecInfo *)hMP3Decoder)->bitrate/1000,    3,    0 );
                     DRAW_DisplayString (0, 5,err_ptr,4);

                     
                     if (((MP3DecInfo *)hMP3Decoder)->nChans == 1)
                         DRAW_DisplayString (33, 5,"KBit - Mono",11);
                     else
                         DRAW_DisplayString (33, 5,"KBit - Stereo",13);  

                     
                    /* Start the playback */
                    AUDIO_Play(AudioBuffer,(mp3FrameInfo.outputSamps*2)); //2buffers
                    
                    /* Enable TIM5 Update interrupt, to call fill buffer */
                    TIM_ITConfig( TIM5, TIM_IT_Update, ENABLE );
                    }
                else
                    {
                    //DRAW_Puts("\n*Raw binary*");
                    AUDIO_SetMode  (AUDIO_CIRCULAR_MODE,LG_16_BITS,FRQ_44KHZ,STEREO); 
                    FillBuffer(1);               
                    AUDIO_Play(AudioBuffer,sizeof(AudioBuffer)/sizeof(s16));
                    /* Enable TIM5 Update interrupt, to call fill buffer */
                    TIM_ITConfig( TIM5, TIM_IT_Update, ENABLE );
                    }
           }



/*******************************************************************************
* Function Name  : Application_Handler
* Description    : Management of the Circle_App.
*
* Input          : None
* Return         : MENU_CONTINUE
*******************************************************************************/
enum MENU_code Application_Handler ( void )
    {
    if ( State == StateExploring ) // Control of statemachine
        {
        switch ( FS_Explorer ( ) )
            {
            case -1: //continue;
                return MENU_CONTINUE;  // No selection has been made yet

            case 0:  //quit the menu, show normal idle screen
                Draw_Display();  
                State = StateIdle; //StateRun;
                return MENU_CONTINUE;

            case +1: //selection done, start playback
               strcpy ( CurrentPath, FS_GetSDCardCurrentPath() );
               AUDIO_Playback_Stop();
               FS_Close  (&file_info);
               State = StateRun;
               OpenAudioFile();
               Read_ID3V1(&file_info);
               PlayAudioFile();
               break;                
            }
        }
    else if ( State == StateRun) // We are playing, runt flying text
        {
        flying_text_write(flying_text,1);
        }
    else if ( State == StateIdle) // we are going in idle, clear text
        {
        flying_text_clear(flying_text,1);
        }
        
    // Handles the touch buttons  
    switch (Get_Touch())
        {
        case Stop:  // Stop playback
           AUDIO_Playback_Stop(); /* Stop the playback */
           TIM_ITConfig( TIM5, TIM_IT_Update, DISABLE );
           State = StateIdle;
        break;
        
        case Play:  /* Play the selected fil from beginning */
           AUDIO_Playback_Stop();
           FS_Close  (&file_info);
        if (strlen(CurrentPath)>1) // Check file is selected
            {
            OpenAudioFile();
            Read_ID3V1(&file_info);
            PlayAudioFile();
            State = StateRun;
            }
        else // Else open file
            {
            FS_Explorer_Ini ( );  /* Opens new file and play file */
            State = StateExploring;
            }
        break;
        
        case Eject: FS_Explorer_Ini ( );  /* Opens new file and play file */
           State = StateExploring;
        break;
        
        case Off: // Shutdown the application 
           DRAW_Clear();
           TIM_ITConfig( TIM5, TIM_IT_Update, DISABLE );
           RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM5, DISABLE ); 
           UTIL_SetIrqHandler  ( 184, (tHandler)old_tim5_irq);
           AUDIO_Playback_Stop();           
           UTIL_SetPll (Old_Pll);
           //NVIC_SystemHandlerPriorityConfig( SysTick_IRQn, 3, 3 );  //SystemHandler_SysTick
           NVIC_SetPriority( SysTick_IRQn, 3 );
           FS_Close  (&file_info);
           return MENU_Quit();
           break;               
        }   
    return MENU_CONTINUE;   // Returning MENU_LEAVE will quit to CircleOS
    }

/*******************************************************************************
* Function Name  : MsgVersion
* Description    : Display the current CircleOS version and the version needed
*                  exit to main menu after 4 secondes
*
* Input          : None
* Return         : MENU_CONTINUE
*******************************************************************************/
enum MENU_code MsgVersion(void)
   {
   int hh,mm,ss,ss2;
   
   DRAW_DisplayString(5,60,"CircleOS",17);
   DRAW_DisplayString(80,60,UTIL_GetVersion(),3);
   DRAW_DisplayString(5,34,NEEDEDVERSION,3);
   DRAW_DisplayString(40,34," required",12);
   
   RTC_GetTime( &hh, &mm, &ss);
   ss = ss + 4;                  // 4 secondes 
   ss = ss%60;
   
   do
        {
        RTC_GetTime( &hh, &mm, &ss2 );
        }  while ( ss2 != ss );           // do while < 4 secondes
   
   return MENU_REFRESH;
   }


/*******************************************************************************
* Function Name  : WaveParsing
* Description    : Taken from the STM examples (i2s_codec.c, UM0549.zip, firmware
*                  of the ST-Eval board for the STM32F103E).
*                  Checks the format of the .WAV file and gets information about
*                  the audio format. This is done by reading the value of a
*                  number of parameters stored in the file header and comparing
*                  these to the values expected authenticates the format of a
*                  standard .WAV  file (44 bytes will be read). If  it is a valid
*                  .WAV file format, it continues reading the header to determine
*                  the  audio format such as the sample rate and the sampled data
*                  size. If the audio format is supported by this application,
*                  it retrieves the audio format in WAVE_Format structure and
*                  returns a zero value. Otherwise the function fails and the
*                  return value is nonzero.In this case, the return value specifies
*                  the cause of  the function fails. The error codes that can be
*                  returned by this function are declared in the header file.
* Input          : None
* Output         : None
* Return         : Zero value if the function succeed, otherwise it return
*                  a nonzero value which specifies the error code.
*******************************************************************************/
ErrorCode I2S_CODEC_WaveParsing(u8* HeaderTab)
    {
    u32 Temp = 0x00;
    u32 ExtraFormatBytes = 0; 
    AUDIO_Frequency_enum i2saudiofreq;

    /* Initialize the HeaderTabIndex variable */
    HeaderTabIndex = 0;

    /* Read chunkID, must be 'RIFF'	----------------------------------------------*/
    Temp = ReadUnit(4, BigEndian);
    if(Temp != ChunkID)
        {
        DRAW_Puts("\nError: Invalid RIFF Id");
        return(Invalid_RIFF_ID);
        }
    /* Read the file length ----------------------------------------------------*/
    WAVE_Format.RIFFchunksize = ReadUnit(4, LittleEndian);

    /* Read the file format, must be 'WAVE' ------------------------------------*/
    Temp = ReadUnit(4, BigEndian);
    if(Temp != FileFormat)
        {
        DRAW_Puts("\nError: Invalid WAVE Format");
        return(Invalid_WAVE_Format);
        }
    /* Read the format chunk, must be 'fmt ' -----------------------------------*/
    Temp = ReadUnit(4, BigEndian);
    if(Temp != FormatID)
        {
        DRAW_Puts("\nError: Invalid Format chunk");
        return(Invalid_FormatChunk_ID);
        }
    /* Read the length of the 'fmt' data, must be 0x10 -------------------------*/
    Temp = ReadUnit(4, LittleEndian);
    if(Temp != 0x10)
        {
        ExtraFormatBytes = 1;
        }
    /* Read the audio format, must be 0x01 (PCM) -------------------------------*/
    WAVE_Format.FormatTag = ReadUnit(2, LittleEndian);
    if(WAVE_Format.FormatTag != WAVE_FORMAT_PCM)
        {
        DRAW_Puts("\nError: Unsupported Format tag");
        return(Unsupporetd_FormatTag);	
        }
    /* Read the number of channels: 0x02->Stereo 0x01->Mono --------------------*/
    WAVE_Format.NumChannels = ReadUnit(2, LittleEndian);

    /* Read the Sample Rate ----------------------------------------------------*/
    WAVE_Format.SampleRate = ReadUnit(4, LittleEndian);
    Real_wav_samplerate = WAVE_Format.SampleRate;
    /* Update the I2S_AudioFreq value according to the .WAV file Sample Rate */
    switch(WAVE_Format.SampleRate)
        {
        case SampleRate_8000 : i2saudiofreq = FRQ_8KHZ;  break; 
        case SampleRate_16000: i2saudiofreq = FRQ_16KHZ; break; 
        case SampleRate_22050: i2saudiofreq = FRQ_22KHZ; break; 	
        case SampleRate_44100: i2saudiofreq = FRQ_44KHZ; break;  		
        case SampleRate_48000: i2saudiofreq = FRQ_48KHZ; break;  		
        default: 
            DRAW_Puts("\nError: Unsupported sample rate");
            return(Unsupporetd_Sample_Rate);
        }	
    WAVE_Format.SampleRate = i2saudiofreq;
    
    /* Read the Byte Rate ------------------------------------------------------*/
    WAVE_Format.ByteRate = ReadUnit(4, LittleEndian);

    /* Read the block alignment ------------------------------------------------*/
    WAVE_Format.BlockAlign = ReadUnit(2, LittleEndian);

    /* Read the number of bits per sample --------------------------------------*/
    WAVE_Format.BitsPerSample = ReadUnit(2, LittleEndian);
    if ( ( WAVE_Format.BitsPerSample != Bits_Per_Sample_16 ) && ( WAVE_Format.BitsPerSample != Bits_Per_Sample_8 ) )
        {
        return(Unsupporetd_Bits_Per_Sample);
        }

    /* If there are Extra format bytes, these bytes will be defined in "Fact Chunk" */
    if(ExtraFormatBytes == 1)
        {
        /* Read th Extra format bytes, must be 0x00 ------------------------------*/
        Temp = ReadUnit(2, LittleEndian);
        if(Temp != 0x00)
            {
            return(Unsupporetd_ExtraFormatBytes);
            }
        /* Read the Fact chunk, must be 'fact' -----------------------------------*/
        Temp = ReadUnit(4, BigEndian);
        if(Temp != FactID)
            {
            return(Invalid_FactChunk_ID);
            }
        /* Read Fact chunk data Size ---------------------------------------------*/
        Temp = ReadUnit(4, LittleEndian);

        /* Set the index to start reading just after the header end */
        HeaderTabIndex += Temp;
        }
    /* Read the Data chunk, must be 'data' -------------------------------------*/
    Temp = ReadUnit(4, BigEndian);
    if(Temp != DataID)
        {
        return(Invalid_DataChunk_ID);
        }
    /* Read the number of sample data ------------------------------------------*/
    WAVE_Format.DataSize = ReadUnit(4, LittleEndian);

    /* Set the data pointer at the beginning of the effective audio data */
    DataStartAddr += HeaderTabIndex;

    return(Valid_WAVE_File);	
    }

/*******************************************************************************
* Function Name  : ReadUnit
* Description    : Reads a number of bytes from the SD card and reorder them
*                  in Big or little endian.
* Input          : - NbrOfBytes : number of bytes to read.
*                    This parameter must be a number between 1 and 4.
*                  - ReadAddr : external memory address to read from.
*                  - Endians : specifies the bytes endianness.
*                    This parameter can be one of the following values:
*                          - LittleEndian
*                          - BigEndian
* Output         : None
* Return         : Bytes read from the SD-Card.
*******************************************************************************/
u32 ReadUnit(u8 NbrOfBytes, Endianness BytesFormat)
    {
    u32 index = 0;
    u32 Temp = 0;

    if(BytesFormat == LittleEndian)
        {
        for(index = 0; index < NbrOfBytes; index++)
            {
            Temp |= AudioFileHeader[HeaderTabIndex++] << (index * 8);
            }
        }
    else
        {
        for(index = NbrOfBytes; index != 0; index--)
            {
            Temp |= AudioFileHeader[HeaderTabIndex++] << ((index-1) * 8);
            }
        }
    return Temp;
    }


/*******************************************************************************
* Function Name  : FillBuffer
* Description    : Fill the buffer with Music from the SD card
* Input          : Start, If 1, we will fill buffer nomatter the status of the playback,
                   used in beginning of file (pre-fill)
* Output         : None
* Return         : void.
*******************************************************************************/
void FillBuffer(u32 start)
    {
    u32 word_Allignment; // Variable used to make sure DMA transfer is alligned to 32bit 
                         // Can maybe be removed if Circle OS is updated for this issue
    u32 n_Read;          // Saves the actual read count from SD card
    u32 err=0;           // Return value from MP3decoder
    u32 offset;          // Used to save the offset to the next frame    
    u32 i;               // Used for misc. loops
    
    if(!start) // If we are in start pos we overwrite bufferstatus.
        BufferStatus = AUDIO_PlaybackBuffer_GetStatus(0);
    else
        BufferStatus = LOW_EMPTY|HIGH_EMPTY;    
    
    if ( strstr(CurrentPath, "MP3") )
    {
        /* somewhat arbitrary trigger to refill buffer - should always be enough for a full frame */
		if (bytesLeft < 2*MAINBUF_SIZE /*&& !eofReached*/) {
        /* move last, small chunk from end of buffer to start, then fill with new data */
         word_Allignment = 4-(bytesLeft&3); // Make sure the first byte in writing pos. is word alligned  
         memmove(readBuf+word_Allignment, readPtr, bytesLeft);	
         FS_ReadFile(&file_info, (u8 *)readBuf+word_Allignment + bytesLeft, &n_Read, READBUF_SIZE - bytesLeft - word_Allignment);
            
            /* zero-pad to avoid finding false sync word after last frame (from old data in readBuf) */
            if (n_Read < READBUF_SIZE - bytesLeft-word_Allignment)
                memset(readBuf + bytesLeft + n_Read, 0, READBUF_SIZE - bytesLeft - n_Read);	          
            bytesLeft += n_Read;
			readPtr = readBuf+word_Allignment;
		}

		/* find start of next MP3 frame - assume EOF if no sync found */
		offset = MP3FindSyncWord(readPtr, bytesLeft);
		if (offset < 0) {
			outOfData = 1;
		}
    
        if(outOfData == 1)
            {
            /* Stop Playback and go back to basic screen*/
            State = StateIdle;
            TIM_ITConfig( TIM5, TIM_IT_Update, DISABLE );
            FS_Close  (&file_info);
            AUDIO_Playback_Stop();
            return; 
            }
    
		readPtr += offset;			 //data start point
		bytesLeft -= offset;		 //in buffer

		if (BufferStatus & LOW_EMPTY) // Decode data to low part of buffer
            {
            err = MP3Decode(hMP3Decoder, &readPtr, (int *)&bytesLeft, (short *)AudioBuffer, 0);
            BufferStatus = AUDIO_PlaybackBuffer_GetStatus(LOW_EMPTY);
            }
 		else if (BufferStatus & HIGH_EMPTY) // Decode data to the high part of buffer
            {
            err = MP3Decode(hMP3Decoder, &readPtr, (int *)&bytesLeft, (short *)AudioBuffer+mp3FrameInfo.outputSamps,0);
            BufferStatus = AUDIO_PlaybackBuffer_GetStatus(HIGH_EMPTY);
            }
        
        if (err) 
            {  
            bytesLeft=0;
            readPtr = readBuf;
            /* error occurred */
            switch (err) // There is not implemeted any error handling. it will quit the playing in case of error
                {
                /* do nothing - next call to decode will provide more mainData */
                case ERR_MP3_MAINDATA_UNDERFLOW: break;
                default: outOfData = 1; break;
                }
            }     
    }
    else // This is the wav part below
    {
        if ( fEOF )
            {
            if ( ( BufferStatus & LOW_EMPTY ) && ( BufferStatus & HIGH_EMPTY ) ) //no more data to play
                {              
                /* Stop Playback and go back to basic screen*/
                State = StateIdle;
                TIM_ITConfig( TIM5, TIM_IT_Update, DISABLE );
                FS_Close  (&file_info);
                AUDIO_Playback_Stop();
                return;
                }
            else return;
            }

        if( BufferStatus & LOW_EMPTY )
            {
            FS_ReadFile(&file_info, (u8 *)AudioBuffer, &i, (sizeof(AudioBuffer)/2));
            BufferStatus = AUDIO_PlaybackBuffer_GetStatus(LOW_EMPTY);

            if ( i < (sizeof(AudioBuffer)/2) )
                {
                fEOF  = 1;
                FS_Close(&file_info);                      
                for((i/=sizeof(s16));i<(sizeof(AudioBuffer)/4);i++)
                    AudioBuffer[i] = 0;
                }
            }
        if( BufferStatus & HIGH_EMPTY )
            {
            FS_ReadFile(&file_info, (u8 *)AudioBuffer+(sizeof(AudioBuffer)/2), &i, (sizeof(AudioBuffer)/2));
            BufferStatus = AUDIO_PlaybackBuffer_GetStatus(HIGH_EMPTY);
      
            if ( i< (sizeof(AudioBuffer)/2) )
                {
                fEOF  = 1;
                FS_Close(&file_info);                      
                for((i/=sizeof(s16));i<(sizeof(AudioBuffer)/4);i++)
                    AudioBuffer[i+(sizeof(AudioBuffer)/2)] = 0;
                }
            }
      }
    return;
    }
