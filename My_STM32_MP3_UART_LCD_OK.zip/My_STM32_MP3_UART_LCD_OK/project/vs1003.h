#ifndef __VS1003_H
#define	__VS1003_H

// Define For VS1002D SCI Register 
#define  	VS_MODE			0x00  	     	// Mode Control
#define  	VS_STATUS		0x01         	// Status
#define  	VS_BASS	    	0x02            // Built-In Bass Enhancer
#define  	VS_CLOCKF		0x03            // Clock Frequency + Double
#define  	VS_DECODE_TIME	0x04            // Decode Time in Second
#define  	VS_AUDATA		0x05            // Misc. Audio Data
#define  	VS_WRAM			0x06            // RAM Write
#define  	VS_WRAMADDR		0x07            // Base Address For RAM Write
#define  	VS_HDAT0		0x08            // Stream Header Data0
#define  	VS_HDAT1		0x09            // Stream Header Data1
#define  	VS_AIADDR	  	0x0A            // Start Address of Application.
#define  	VS_VOL	        0x0B            // Volume Control
#define  	VS_AICTRL0		0x0C            // Application Control Register. 0
#define  	VS_AICTRL1		0x0D            // Application Control Register. 1
#define  	VS_AICTRL2		0x0E            // Application Control Register. 2
#define  	VS_AICTRL3    	0x0F            // Application Control Register. 3	

#define		XTAL_12288		0x9800
#define		XTAL_24576		0x3000
#define 	DEFAULT_VOLUME 	0x0101			/* default volumn */

#define CLOCK_REG       0x9800        //0x9800 is for VS1011 VS1002


#define  VS1003B_XCS 		       		GPIO_Pin_10			//XCS = PB[8]
#define  VS1003B_XCS_PORT		       	GPIOB

#define  VS1003B_SCK		       		GPIO_Pin_11			//SCK = PB[9]
#define  VS1003B_SCK_PORT		       	GPIOB

#define  VS1003B_MOSI		       		GPIO_Pin_12			//MOSI = PB[10]
#define  VS1003B_MOSI_PORT	            GPIOB

#define  VS1003B_XDCS	           		GPIO_Pin_13			//XDCS = PB[11]
#define  VS1003B_XDCS_PORT	       		GPIOB

#define  VS1003B_XRESET		       		GPIO_Pin_14			//RESET = PB[12]
#define  VS1003B_XRESETPORT	       		GPIOB

#define  VS1003B_MISO	           		GPIO_Pin_15			//MISO = PB[13]
#define  VS1003B_MISO_PORT	           	GPIOB

#define  VS1003B_DREQ	           		GPIO_Pin_7			//DREQ = PB[14]===//CHAN VOLUME
#define  VS1003B_DREQ_PORT	           	GPIOB


#define  UP						  GPIO_Pin_5	//VOLUME UP_OK
#define  DOWN						GPIO_Pin_9  //VOLUME DOWN_OK
#define  PAUSE_PLAY			GPIO_Pin_0	//_PIN 7 ko cha.y do phan cu'ng
#define  NEXT						GPIO_Pin_8  //NEXT_OK
#define  BACK					  GPIO_Pin_1  //_OK

#define	VS1003B_SCK_H()		GPIO_SetBits   (GPIOB,VS1003B_SCK);
#define	VS1003B_SCK_L()		GPIO_ResetBits (GPIOB,VS1003B_SCK);
#define	VS1003B_XDCS_H()	GPIO_SetBits   (GPIOB,VS1003B_XDCS);
#define	VS1003B_XDCS_L()	GPIO_ResetBits (GPIOB,VS1003B_XDCS);
#define	VS1003B_XCS_H()		GPIO_SetBits   (GPIOB,VS1003B_XCS);
#define	VS1003B_XCS_L()		GPIO_ResetBits (GPIOB,VS1003B_XCS);
#define	VS1003B_XRESET_H()	GPIO_SetBits   (GPIOB,VS1003B_XRESET);
#define	VS1003B_XRESET_L()	GPIO_ResetBits (GPIOB,VS1003B_XRESET);


extern unsigned char VS1003B_NeedData (void);
extern unsigned char VS1003B_Init(void);			/* Initialization, include prot and chip config */
extern unsigned short VS1003B_ReadDecodeTime(void);	/* Get current decode time, for time display */
extern void VS1003B_Write32B(unsigned char * buf);	/* write 32bytes data */
extern void VS1003B_SetVolume(unsigned short vol);  /* Set volume */
extern void VS1003B_Fillclear (void);
extern void VS1003B_SoftReset (void);
extern void dreq_request (void);
//extern void test (void);


#endif
