/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_lib.h"
#include "platform_config.h"
#include "stdio.h"
#include "uart.h"
#include "sdmmc.h"
#include "vs1003.h"
#include "fat.h"
#include "lcd.h"
#include "reprintf.h"
#include "myLib.h"
GPIO_InitTypeDef GPIO_InitStructure;
ErrorStatus HSEStartUpStatus;


// Private functions ---------------------------------------------------------//
// Function Name  : RCC_Configuration
//Description    : Configures the different system clocks.
//
void RCC_Configuration(void)
{   
  /* RCC system reset(for debug purpose) */
  RCC_DeInit();
  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);
  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if(HSEStartUpStatus == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);
    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1); 
    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1); 
    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);
    /* PLLCLK = 8MHz * 9 = 72 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
     /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);
     /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }
    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
}
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX



//-----------------------------------------------------------------------------//
//Function Name  : NVIC_Configuration
//Description    : Configures Vector Table base location.
// Input          : None
void NVIC_Configuration(void)
{
#ifdef  VECT_TAB_RAM  
  /* Set the Vector Table base location at 0x20000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
#endif
}
//------------------------------------------------------------------------------//

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#define 	MP3 1
// Long name buffer and flag //
extern unsigned char LongNameBuffer[MAX_LONG_NAME_SIZE];
//
extern unsigned char LongName_in[80];
//
extern unsigned char LongNameFlag;

// indicate if the file system is FAT32 , ortherwise it is FAT16, note FAT12 is not supported //
extern BYTE FAT32_Enable;

extern WORD SectorsPerClust;
extern WORD FirstDataSector;

// The path of the music file & lyric file , caution: each driectory should long longer than 8, that is not support long name//
#define LRC_PATH "\\lrc"

struct direntryBytes MusicInfo;	// Music file information, 32Bytes short directory record, contain the short name and others //
struct direntryBytes LrcInfo;	// lyric file information, 32Bytes short directory record, the short name and others //

uint16 		totalsongs;		// total number of songs//
uint8 		type;			// current song's file type, mp3 wma mid or wav //
uint8 		lrc =0;			// Gloable variable to indicate wether the songs has a lyric file, 1 means have //
uint8 		dis;

// Time tag structure //
struct LrcStruct_s {
	struct LrcStruct_s * next;	// the next node //
	uint32 time;				// Time //
	uint16 eeaddr;			// Address, start with 0, value greater than MAXLRCDATSIZE is the eeprom address//
};
typedef struct LrcStruct_s LrcStruct_s;
//--------------------------------------------------------------------------------//
struct LrcStructHead_s {
	struct LrcStruct_s *header;	// Pointer to the first node of time tag struct //
#define TI_LEN 32
	uint8 title[TI_LEN];			// Title //
#define AR_LEN 16
	uint8 artist[AR_LEN];			// Artist //
	uint16 offset;					// Offset //
       uint8 sign;					// "1" means "+", and "0" means "-" //
};
//typedef struct LrcStructHead_s LrcStructHead_s;
//--------------------------------------------------------------------------------//
#define DEBUG 0	// Macro for DEBUG, if 1 DEBUG message will show throw the UART //

//--------------------------------------------------------------------------------//
struct LrcStructHead_s LrcStructHead;	// Gloable struct variable to record the lyric info //
//--------------------------------------------------------------------------------//
// Use to record the time tag info //
#define MAXITEM 120
uint8 lrcbuffer[sizeof(struct LrcStruct_s) * MAXITEM];

// Use to record the lyric data //
#define MAXLRCDATSIZE 4096			// Max data size in SRAM, other will be store in EEPROM of ATmega64 //
uint8 lrcdatbuf[MAXLRCDATSIZE];


uint8 track[128];			// stroe the information of songs (bit set indicate songs has been played) //
//--------------------------------------------------------------------------------//
void ClearTrackInfo()		// cleare the array track[128] //
{
	uint8 i;
	for(i=0;i<128;i++)track[i] = 0;
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

unsigned short vol1;
char c;
int list=1;
uint16 songs = 1;		//play the fist songs by default

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//--------------------------------------------------------------------------------//
uint8 SetTrack(uint16 songs)// set the track bit, return 1 means the song has been played //
{
	uint8 byte_offset;
	uint8 bit_offset;
	songs--;
	byte_offset = songs/8;
	bit_offset = songs%8;
	if(track[byte_offset] & (1<<bit_offset))return 1;
	else
	{
		track[byte_offset] |= 1<<bit_offset;
		return 0;
	}
}
//--------------------------------------------------------------------------------//
void Delay(uint16 n)
{
	while(n--);
}
//------------------------------------------------------------------------------//
//------------------------------------------------------------------------------//
//------------------------------------------------------------------------------//
//---------------------------------------------------------------------------------//


//print_name(LongNameBuffer);
//extern unsigned char LongNameBuffer[MAX_LONG_NAME_SIZE=80];
void print_name (uint8 *filename)
{
	
	uint8 i;
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	
if(list)
{
	setTargetDev(DEV_LCD);
	lcd_Clear();
	printf ("Play:%d/%d",songs,totalsongs);
	lcd_GotoXY(1,0);	
	for (i=0;i<32;i+=2)
	{
		if ((i >= MAX_LONG_NAME_SIZE) || (filename[i] == '.'))
			break;
		printf ("%c",filename[i]);
	}
	printf (".mp3");
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
setTargetDev(DEV_USART1);
	printf ("\r\nPlay : ");
	for (i=0;;i++)
	{
		if ((i >= MAX_LONG_NAME_SIZE) || (filename[i] == '.'))
			break;
		printf ("%c",filename[i]);

	}
}
else
{
		setTargetDev(DEV_USART1);
	printf ("\r\nPlay : ");
	for (i=0;;i++)
	{
		if ((i >= MAX_LONG_NAME_SIZE) || (filename[i] == '.'))
			break;
		printf ("%c",filename[i]);
	}
}

}

//-------------------------------------------------------------------------------//
uint8 LrcProc(uint8 *LongNameBuffer,WORD music_record_addr) // Parameter is the song's long name or short name, note: do not contain the extention//
{ 
	SearchLrc(LRC_PATH,LongNameBuffer,&LrcInfo,music_record_addr);	// search the path specified, and if found lyric file it will return 0//

	return 0;
}
//---------------------------------------------------------------------------------//

uint8 PlayMusicwithKey()
{
	uint16 keylen;			//for key processing
	uint16 count;			//data counting
	uint8 i;				//loop variable
	uint16 j;				//loop variable	
	DWORD p;				//cluster
	DWORD totalsect;		//cotain the total sector number of a file
	uint16 leftbytes;		//cotain the left bytes number of a file //the last cluster usually not fully occupied by the file
	uint8 *buffer;			//buffer
	DWORD sector;			//recor the current sector to judge the end sector
	uint8 flag;				//flag of pause
//	uint16 songs = 1;		//play the fist songs by default
#define MAX_LRC_DISP 52
	uint16 lrcaddr;
 	ClearTrackInfo();
	if (totalsongs == 0)
	{
		printf ("\r\nFile not found");
		return 0;
	}	

next:
	count=0;//clear count
	flag=1;
	
	//Search(0,&MusicInfo,&totalsongs,&type);

		VS1003B_SoftReset();//soft reset //in case of playing wma files
   	Search(&lrcaddr,&MusicInfo,&songs,&type);////ko co dong nay thi chi mo bai cuoi cung	
	//#define MAX_LONG_NAME_SIZE 80		/* 26*n+2   n=3 */
	//extern unsigned char LongNameBuffer[MAX_LONG_NAME_SIZE];
//extern unsigned char LongNameFlag;

		for(j=0;j<MAX_LONG_NAME_SIZE/2;j++)/* cut off the extension, only leave the name*/
		{
			if(((uint8 *)LongNameBuffer)[j] == 0)
			{
				((uint8 *)LongNameBuffer)[j-4] = 0;//tru di 4 ki tu .MP3=>mang *LongNameBuffer chua ten file
				break;
			}
		}
		if(!LongNameFlag)//BYTE LongNameFlag = 0;
		{
			for(j=0;j<8;j++)
			{
				//	BYTE		deName[8];      	// filename, blank filled
				//#define ATTR_ARCHIVE    0x20            // file is new or modified
				if(MusicInfo.deName[j]==0x20) break;
				LongNameBuffer[j]=MusicInfo.deName[j];
			}
			LongNameBuffer[j++]='\0';
			LongNameBuffer[j++]='.';
			count = j+3;
			for(count=0;count<3;count++)// lay duoi file
			//	BYTE		deExtension[3]; 	// extension, blank filled
				LongNameBuffer[j+count]=MusicInfo.deExtension[count];
			LongNameBuffer[j+count]='\0';
		}
		
		
		//xuat ten bai nhac qua UART
		print_name(LongNameBuffer);

	p     = get16_little(MusicInfo.deStartCluster)+(((uint32)get16_little(MusicInfo.deHighClust))<<16);	//the first cluster of the file
		
		totalsect = get32_little(MusicInfo.deFileSize)/512; //calculate the total sectors
		leftbytes = get32_little(MusicInfo.deFileSize)%512; //calculate the left bytes	
		i=0;
		sector=0;

  while(1)
	{
			VS1003B_SetVolume(vol1);//khi next thi van giu muc volume		
	   	keylen = 0;
		//extern WORD SectorsPerClust;
	   	for(;i<SectorsPerClust;i++)		//a cluster// co' sector++
			{
				buffer=malloc(512);
				FAT_LoadPartCluster(p,i,buffer);//read a sector												
				count=0;
		
while(count<512)//4BUTTON
{
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX		
	//khi flag=0 thi ham VS1003B_NeedData ko dc goi=>pause
	//PLAY
			if(VS1003B_NeedData() && flag)//VS1003B_NeedData() co data=>tra ve 1
					{
						VS1003B_Write32B(&buffer[count]);
						count += 32;
						if(keylen)
							keylen--;	//for key processing
						if(sector == totalsect && count >= leftbytes)//if this is the end of the file
						{
							i = SectorsPerClust;
							break;
						}		//file ended
						if(count == 511)
						{
							break;
						}	
					}
				else
				{
					;
				}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/**/
if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE))
{
c = USART_ReceiveData(USART1);
	if(c=='N')
	{	
		printf("\r\n=>");
		songs++;
		if (songs > totalsongs) songs = 1;
		printf ("\r\n %d / %d",songs,totalsongs);
		free(buffer);
		goto next;
	}
	else if(c=='B')
	{
		printf("\r\n<=");
		songs--;
		if (songs ==0) songs = totalsongs;
		printf ("\r\n %d / %d",songs,totalsongs);
		free(buffer);
		goto next;
	}
	else if(c=='U')
	{
		vol1=vol1-((uint16)(1<<8)+1);
		if(vol1<=0x0101)
				vol1=0x0101;
		else 
				VS1003B_SetVolume(vol1);
	}
	else if (c=='D')
	{
		vol1=vol1+((uint16)(1<<8)+1);
		if(vol1>=0xFEFE) 
				vol1=0xFEFE; 
	  else 
				VS1003B_SetVolume(vol1);
	}
	else if (c=='P')
		flag=0;
	else if(c=='R')
		flag=1;
	else if(c=='L')
	{
		printf ("\r\nPlayList : ");
		/////////////////////////////
		
	//	for(i=0;i<totalsongs;i++)
	//	{	
/**/	print_name(LongName_in);
	//	}
		/////////////////////////////

	}
	else
	{
		;
	}

}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX					
					if((GPIOB->IDR & PAUSE_PLAY)==0 /*&& keylen==0*/)	//key PLAY/PAUSE
				{
	 			  Delay(100);
					if(!(GPIOB->IDR & PAUSE_PLAY))
					{
						while(!(GPIOB->IDR & PAUSE_PLAY));
						 if(flag)flag=0;
						 else flag=1;
						 Delay(1000);
					}
					
				}
			  	else if ((GPIOB->IDR & NEXT)==0)//NEXT
					{
					  printf("\r\n=>"); 
						songs++;
						if (songs > totalsongs) songs = 1;
						 printf ("\r\n %d / %d",songs,totalsongs);
						free(buffer);
						goto next;
					}
					else if ((GPIOB->IDR & BACK)==0)//BACK
					{
					  printf("\r\n<="); 
						songs--;
						if (songs ==0) songs = totalsongs;
						 printf ("\r\n %d / %d",songs,totalsongs);
						free(buffer);
						goto next;
					}
//////////////////////////////////////////////////////////////////////////
	    else if(!(GPIOB->IDR&DOWN) && keylen==0)//Volume down							
				{ 
				    Delay(100);
	   			 	if(!(GPIOB->IDR&DOWN))  
					{
					keylen=200;
					   vol1=vol1+((uint16)(1<<8)+1);
					   if(vol1>=0xFEFE) 
							 vol1=0xFEFE; 
	   			   else 
							 VS1003B_SetVolume(vol1);
					 }
	 			 }
			 else if (!(GPIOB->IDR&UP) && keylen==0) 		//Volume up
	  			 {
					 Delay(100);
				 	 if(!(GPIOB->IDR&UP)) 
					 {
					 keylen=200;
					   vol1=vol1-((uint16)(1<<8)+1);
					   if(vol1<=0x0101)
							 vol1=0x0101;
					   else 
							 VS1003B_SetVolume(vol1);
	   			  }
				  }				
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX					
		}
				sector++;
				free(buffer);
			}
			i=0;
       p=FAT_NextCluster(p);
		if(p == 0x0fffffff || p == 0x0ffffff8 || (FAT32_Enable == 0 && p == 0xffff))	//no more cluster
		{
		   	songs++;
			if(songs>totalsongs)
				songs = 1;
			goto next;
		}

 };
}
//------------------------------------------------------------------------------//
int main(void)
{
  	// System Clocks Configuration 
  	RCC_Configuration();   
  	// NVIC Configuration 
  	NVIC_Configuration();
	
	init_serial();   // Enable USART1                             
	spi_init ();	// SPI1 enable 	//SPI  truyen song cong voi SD
	VS1003B_Init ();//VS1003_Configuration 
 /* initialize LCD */
	lcd_Init();
	lcd_Clear();
	
	setTargetDev(DEV_LCD);//lua chon truyen qua LCD
  lcd_GotoXY(0,6);
	printf("KMT_07");
	lcd_GotoXY(1,4);
	printf("STM32-MP3");
	
	setTargetDev(DEV_USART1);//lua chon truyen qua UART
	while(MMC_SD_Init());//SD Card_Configuration 
	printf(("\r\nSD initialize OK!"));

	FAT_ReadSector   = MMC_SD_ReadSingleBlock;//device read
	FAT_WriteSector  = MMC_SD_WriteSingleBlock;//device write
	FAT_ReadCapacity = MMC_SD_ReadCapacity;//read capacity
	printf(("\r\nDisk size is: %ld MB"),FAT_ReadCapacity()/1024/2);
	
	if(FAT_Init())//ham con FAT_Init tra ve 0 nghia la dinh dang OK
	{							//if(dieu kien sai)=> else dung 
		printf(("\r\nFAT initialize fialed! Or System error!"));
		while(1);
	}
	else 
	{
		printf(("\r\nFAT initialize OK!"));
	}
	dis = 1;
	SearchInit();
	Search(0,&MusicInfo,&totalsongs,&type);
	printf ("\r\n\nFound %d songs\r\n",totalsongs);
	dis = 0;
  
  lcd_Clear();	
	PlayMusicwithKey();

	while (1); 
}
//------------------------------------------------------------------------------//
